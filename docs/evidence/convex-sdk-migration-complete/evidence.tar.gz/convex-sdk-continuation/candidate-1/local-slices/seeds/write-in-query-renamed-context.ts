import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
query({args:{},handler:async(context)=>{await context.db.patch("id",{});}});