import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const handler=async(ctx)=>{await ctx.db.patch("id",{lastSeen:1});};const selected=flag?mutation:external;selected({args:{},handler});
mutation({args:{},handler:async(ctx)=>{await ctx.db.patch("id",{lastSeen:1});}});