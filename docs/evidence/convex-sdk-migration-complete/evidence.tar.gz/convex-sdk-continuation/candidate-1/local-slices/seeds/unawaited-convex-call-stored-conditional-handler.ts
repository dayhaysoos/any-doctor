import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const handler=async(ctx)=>{ctx.db.patch("id",{});};const selected=flag?mutation:external;selected({args:{},handler});
mutation({args:{},handler:async(ctx)=>{ctx.db.patch("id",{});}});