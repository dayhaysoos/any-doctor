import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
((mutation as typeof mutation)!)({args:{},handler:async(ctx)=>{ctx.db.patch("id",{});}});