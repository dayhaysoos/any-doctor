import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const handler=async(ctx)=>{return ctx.db.query("rows").collect();};const selected=flag?query:external;selected({args:{},handler});
query({args:{},handler:async(ctx)=>{return ctx.db.query("rows").collect();}});