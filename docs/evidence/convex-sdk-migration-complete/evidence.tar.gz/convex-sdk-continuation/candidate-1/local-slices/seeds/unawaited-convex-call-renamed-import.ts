import {query as read,mutation as write,action as act} from "./_generated/server"; import {api,internal} from "./_generated/api";
write({args:{},handler:async(ctx)=>{ctx.db.patch("id",{});}});