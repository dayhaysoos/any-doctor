import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const handler=async(ctx)=>{return ctx.runQuery(api.rows.list,{});};const selected=flag?action:external;selected({args:{},handler});
action({args:{},handler:async(ctx)=>{return ctx.runQuery(api.rows.list,{});}});