import {query,mutation,action} from "./_generated/server";const registered=mutation; import {api,internal} from "./_generated/api";
registered({args:{},handler:async(ctx)=>{ctx.db.patch("id",{});}});