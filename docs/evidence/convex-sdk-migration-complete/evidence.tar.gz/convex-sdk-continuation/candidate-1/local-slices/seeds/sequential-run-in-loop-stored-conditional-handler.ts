import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const handler=async(ctx)=>{for(const id of ids){await ctx.runQuery(internal.rows.list,{id});}};const selected=flag?action:external;selected({args:{},handler});
action({args:{},handler:async(ctx)=>{for(const id of ids){await ctx.runQuery(internal.rows.list,{id});}}});