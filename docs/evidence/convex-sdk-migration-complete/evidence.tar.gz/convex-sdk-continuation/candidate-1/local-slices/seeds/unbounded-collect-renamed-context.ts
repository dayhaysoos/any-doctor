import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
query({args:{},handler:async(context)=>{return context.db.query("rows").collect();}});