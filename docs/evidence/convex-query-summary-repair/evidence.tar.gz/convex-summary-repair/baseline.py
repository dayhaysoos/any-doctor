import pathlib,subprocess,json,time,os,signal,hashlib
R=pathlib.Path('/Users/nickdejesus/Code/any-doctor');O=pathlib.Path(__file__).parent;os.environ['PATH']='/Library/Developer/CommandLineTools/usr/bin:'+os.environ['PATH']
state={k:subprocess.check_output(['git',*args],cwd=R,text=True).strip() for k,args in {'branch':['branch','--show-current'],'head':['rev-parse','HEAD'],'status':['status','--porcelain'],'recent':['log','-6','--format=%H %s']}.items()};(O/'starting-state.json').write_text(json.dumps(state,indent=2))
for f in ['doctors/convex.mjs','src/sdk.ts','bin/sdk.js']:
 p=O/'starting-files'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/f).read_bytes())
seeds={
'opaque-range':'''import { query } from "./_generated/server";
query({args:{},handler:async (ctx,args)=>ctx.db.query("rows").withIndex("by_x", q=>args.bound(q)).filter(q=>q.eq(q.field("active"),true)).collect()});
''',
'computed-patch':'''import { mutation } from "./_generated/server";
mutation({args:{},handler:async (ctx,args)=>{await ctx.db.patch("id",{[args.field]:args.value});}});
''',
'spread-patch':'''import { mutation } from "./_generated/server";
mutation({args:{},handler:async (ctx,args)=>{await ctx.db.patch("id",{...args});}});
''',
'no-needs':'work();\n',
}
for n in [20,80,160,320,1000]:seeds['scaling-'+str(n)]='import {query} from "./_generated/server";\nquery({args:{},handler:async ctx=>{\nlet builder=ctx.db.query("rows");\n'+('builder=builder.filter(q=>q.eq(q.field("x"),1));\n'*n)+'await builder.collect();\n}});\n'
rows=[]
for name,source in seeds.items():
 P=O/'before'/name;P.mkdir(parents=True);T=P/'seed';T.mkdir();(T/'entry.ts').write_text(source)
 doctor=R/'doctors/convex.mjs'
 if name=='no-needs':
  doctor=P/'doctor.mjs';doctor.write_text('export const meta={id:"probe",description:"probe",severity:"warning",checks:[{id:"plain",description:"plain"}]};export async function doctor(ctx){ctx.report.narrowing({check:"plain",file:"entry.ts",reason:"unresolved-identity"});}')
 cmd=['node',str(R/'bin/cli.js'),'run',str(doctor),str(T),'--format','json'];env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=128'};start=time.monotonic();p=subprocess.Popen(cmd,cwd=R,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timed=False
 try:out,err=p.communicate(timeout=20)
 except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGTERM);out,err=p.communicate()
 (P/'stdout').write_text(out);(P/'stderr').write_text(err)
 try:scan=json.loads(out)
 except:scan=None
 row={'name':name,'sourceBytes':len(source.encode()),'assignments':int(name.split('-')[1]) if name.startswith('scaling') else None,'command':cmd,'heapMB':128,'timeoutSeconds':20,'timedOut':timed,'exit':p.returncode,'wallMs':round((time.monotonic()-start)*1000),'findings':scan and scan.get('counts'),'score':scan and scan.get('score'),'narrowings':scan and [n for g in scan.get('groups',[]) for n in g.get('semantic',{}).get('narrowed',[])]};rows.append(row);(P/'result.json').write_text(json.dumps(row,indent=2));print(name,row['exit'],row['wallMs'],flush=True)
(O/'before-results.json').write_text(json.dumps(rows,indent=2))
