import pathlib,subprocess,json,hashlib,os,time,sys
R=pathlib.Path('/Users/nickdejesus/Code/any-doctor');O=pathlib.Path(__file__).parent;name=sys.argv[1];C=pathlib.Path(sys.argv[2] if len(sys.argv)>2 else R).resolve();D=O/name;D.mkdir();T=pathlib.Path('/tmp/any-doctor-frozen-sift');env={**os.environ,'PATH':'/Library/Developer/CommandLineTools/usr/bin:'+os.environ['PATH']}
def run(name,cmd,expected=0):
 cmd=list(map(str,cmd));start=time.monotonic();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True);(D/(name+'.stdout')).write_text(p.stdout);(D/(name+'.stderr')).write_text(p.stderr);(D/(name+'.command.json')).write_text(json.dumps({'command':cmd,'exit':p.returncode,'wallMs':round((time.monotonic()-start)*1000),'cwd':str(R)},indent=2));assert p.returncode==expected,(name,p.stdout[-600:],p.stderr[-600:]);print(name,p.returncode,flush=True);return p
run('convex',['node',C/'bin/cli.js','verify',C/'doctors/convex.mjs','--format','json'])
for label,script in [('existing','dev/convex-analysis/run-cases.mjs'),('guardrails','dev/convex-sdk-migration/run-guardrails.mjs'),('slices','dev/convex-sdk-migration/run-slices.mjs'),('repair','dev/convex-summary-repair/run-controls.mjs'),('scaling','dev/convex-summary-repair/run-scaling.mjs')]:run(label,['node',R/script,C,D/label])
run('recipes',['node',R/'dev/convex-sdk-migration/probe-recipes.mjs',C]);run('unavailable',['node',R/'dev/convex-sdk-migration/repro-unavailable.mjs'])
env['DOCTOR_CANDIDATE_ROOT']=str(C);run('sdk-and-integration',['node','--test',R/'test/sdk-custom-narrowing.test.mjs',R/'test/convex-sdk-migration.test.mjs',R/'test/convex-summary-repair.test.mjs']);del env['DOCTOR_CANDIDATE_ROOT']
for phase in ['before','after']:
 M=json.loads((R/'docs/evidence/consumer-analysis/sift-manifest.json').read_text());bad=[f['file'] for f in M['files'] if hashlib.sha256((T/f['file']).read_bytes()).hexdigest()!=f['sha256']];(D/('manifest-'+phase+'.json')).write_text(json.dumps({'entries':len(M['files']),'matched':len(M['files'])-len(bad),'mismatches':bad},indent=2));assert not bad
 if phase=='before':run('sift',['node',C/'bin/cli.js','run',C/'doctors/convex.mjs',T,'--format','json'])
for label in ['opaque-range','computed-patch','spread-patch','no-needs']:
 doctor=O/'before/no-needs/doctor.mjs' if label=='no-needs' else C/'doctors/convex.mjs'
 run('original-'+label,['node',C/'bin/cli.js','run',doctor,O/'before'/label/'seed','--format','json'],1 if label=='no-needs' else 0)
print('ALL PASS',flush=True)
