import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const ordinary=config=>config;ordinary({handler:async(ctx)=>{return 1;}});