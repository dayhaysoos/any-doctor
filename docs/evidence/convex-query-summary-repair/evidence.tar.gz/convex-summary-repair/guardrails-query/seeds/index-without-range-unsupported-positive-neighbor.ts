import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const selected=flag?query:external;selected({args:{},handler:async(ctx)=>{return ctx.db.query("rows").withIndex("by_x").collect();}});
query({args:{},handler:async(ctx)=>{return ctx.db.query("rows").withIndex("by_x").collect();}});