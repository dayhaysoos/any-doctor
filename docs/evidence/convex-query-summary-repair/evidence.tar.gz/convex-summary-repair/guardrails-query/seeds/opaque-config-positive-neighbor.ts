import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
query(configure());query({handler:async(ctx)=>1});