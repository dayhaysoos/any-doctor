import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const selected=flag?query:external;selected({args:{},handler:async(ctx)=>{await ctx.db.patch("id",{});}});
query({args:{},handler:async(ctx)=>{await ctx.db.patch("id",{});}});