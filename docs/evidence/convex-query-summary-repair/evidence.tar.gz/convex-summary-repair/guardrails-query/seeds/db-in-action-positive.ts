import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
action({args:{},handler:async(ctx)=>{return ctx.db.get("id");}});