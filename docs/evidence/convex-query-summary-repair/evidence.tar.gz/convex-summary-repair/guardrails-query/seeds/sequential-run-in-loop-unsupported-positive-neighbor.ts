import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const selected=flag?action:external;selected({args:{},handler:async(ctx)=>{for(const id of ids){await ctx.runQuery(internal.rows.list,{id});}}});
action({args:{},handler:async(ctx)=>{for(const id of ids){await ctx.runQuery(internal.rows.list,{id});}}});