import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
query({handler:async(ctx)=>{return 1;}});query({handler:async(ctx)=>{return 1;}});