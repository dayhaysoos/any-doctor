import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
query({args:{},handler:async(ctx)=>{await ctx.db.patch("id",{});}});