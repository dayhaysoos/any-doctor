import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const ordinary=config=>config;ordinary({args:{},handler:async(ctx)=>{return Date.now();}});