import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const selected=flag?mutation:external;selected({args:{},handler:async(ctx)=>{await ctx.db.patch("id",{...fields});}});
mutation({args:{},handler:async(ctx)=>{await ctx.db.patch("id",{...fields});}});