"use node";
import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const selected=flag?query:external;selected({args:{},handler:async(ctx)=>{return 1;}});
query({args:{},handler:async(ctx)=>{return 1;}});