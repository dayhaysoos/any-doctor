import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const selected=flag?mutation:external;selected({args:{},handler:async(ctx)=>{ctx.db.patch("id",{});}});
mutation({args:{},handler:async(ctx)=>{ctx.db.patch("id",{});}});