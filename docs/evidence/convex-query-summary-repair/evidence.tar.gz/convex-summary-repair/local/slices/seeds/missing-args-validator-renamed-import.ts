import {query as read,mutation as write,action as act} from "./_generated/server"; import {api,internal} from "./_generated/api";
read({handler:async(ctx)=>{return 1;}});