import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
const handler=async(ctx)=>{return 1;};const selected=flag?query:external;selected({handler});
query({handler:async(ctx)=>{return 1;}});