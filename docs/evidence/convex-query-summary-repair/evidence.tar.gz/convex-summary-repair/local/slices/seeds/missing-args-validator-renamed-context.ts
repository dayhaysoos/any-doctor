import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
query({handler:async(context)=>{return 1;}});