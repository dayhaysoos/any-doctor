import {query,mutation,action} from "./_generated/server";const registered=query; import {api,internal} from "./_generated/api";
registered({handler:async(ctx)=>{return 1;}});