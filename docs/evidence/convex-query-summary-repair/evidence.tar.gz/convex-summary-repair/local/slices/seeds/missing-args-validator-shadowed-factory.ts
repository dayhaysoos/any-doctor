import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
{const query=value=>value;query({handler:async(ctx)=>{return 1;}});}