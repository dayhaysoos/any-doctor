"use node";
import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
{const query=value=>value;query({args:{},handler:async(ctx)=>{return 1;}});}