import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
((query as typeof query)!)({handler:async(ctx)=>{return 1;}});