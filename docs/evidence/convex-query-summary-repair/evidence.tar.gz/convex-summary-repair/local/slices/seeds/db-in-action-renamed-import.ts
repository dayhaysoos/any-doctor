import {query as read,mutation as write,action as act} from "./_generated/server"; import {api,internal} from "./_generated/api";
act({args:{},handler:async(ctx)=>{return ctx.db.get("id");}});