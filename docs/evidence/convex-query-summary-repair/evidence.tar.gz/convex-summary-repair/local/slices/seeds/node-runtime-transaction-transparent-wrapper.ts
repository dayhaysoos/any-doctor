"use node";
import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
((query as typeof query)!)({args:{},handler:async(ctx)=>{return 1;}});