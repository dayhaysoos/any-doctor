import {query,mutation,action} from "./_generated/server"; import {api,internal} from "./_generated/api";
{const action=value=>value;action({args:{},handler:async(ctx)=>{return ctx.db.get("id");}});}