import {query,mutation,action} from "./_generated/server";const registered=action; import {api,internal} from "./_generated/api";
registered({args:{},handler:async(ctx)=>{return ctx.db.get("id");}});