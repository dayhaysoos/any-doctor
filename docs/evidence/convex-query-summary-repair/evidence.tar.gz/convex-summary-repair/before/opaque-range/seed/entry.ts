import { query } from "./_generated/server";
query({args:{},handler:async (ctx,args)=>ctx.db.query("rows").withIndex("by_x", q=>args.bound(q)).filter(q=>q.eq(q.field("active"),true)).collect()});
