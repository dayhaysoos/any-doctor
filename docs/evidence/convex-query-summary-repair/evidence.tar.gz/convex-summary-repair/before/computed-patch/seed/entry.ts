import { mutation } from "./_generated/server";
mutation({args:{},handler:async (ctx,args)=>{await ctx.db.patch("id",{[args.field]:args.value});}});
