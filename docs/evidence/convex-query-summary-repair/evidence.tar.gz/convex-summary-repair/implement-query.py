from pathlib import Path
p=Path('doctors/convex.mjs');s=p.read_text();old=s[s.index('function checkQueryChains'):];start=old.index('      let ranged=false,unknown=false;');end=old.index('      let rule;',start);rangebody=old[start:end];rangebody='\n'.join(line[4:] for line in rangebody.splitlines());
new='''// One memoized source graph per file; locations never identify semantic states.
function createQuerySummarizer(facts,m){
  const origins=new Map(),ranges=new Map();
  const method=call=>call.target.members.at(-1);
  const edge=(kind,id)=>`${kind}:${id}`;
  const callById=m.calls;
  const join=(a,b)=>a===b?a:2; // 0=no, 1=yes, 2=unknown
  function indexRange(index){
    if(ranges.has(index.end))return ranges.get(index.end);
RANGEBODY
    const result=unknown?2:ranged?1:0;ranges.set(index.end,result);return result;
  }
  // Cache direct origin edges instead of repeatedly flattening initializer/write
  // histories. Binding and value identity are distinct graph-node namespaces.
  function origin(key){
    if(origins.has(key))return origins.get(key);
    const colon=key.indexOf(':'),kind=key.slice(0,colon),id=Number(key.slice(colon+1));
    const result={edges:[],uncertain:false,convex:false};origins.set(key,result);
    if(kind==='binding'){
      const b=m.bindings.get(id);
      if(b&&!b.path?.length){
        result.uncertain=!!(b.reassigned||b.mutated);
        result.edges=[...new Set([b.initializer,...(b.writes??[]).map(w=>w.value)].filter(v=>v!==undefined))].map(v=>edge('value',v));
      }
    }else if(kind==='value'){
      const v=m.values.get(id);
      if(v?.kind==='call')result.edges=[edge('call',v.value)];
      if(v?.kind==='alias')result.edges=[edge('value',v.value)];
      if(v?.kind==='choice')result.edges=v.alternatives.map(v=>edge('value',v));
      if(v?.kind==='reference'&&!v.target.members.length&&v.target.binding!==null)result.edges=[edge('binding',v.target.binding)];
    }else{
      const call=callById.get(id);result.call=call;
      if(call){
        if(call.receiverCall!==undefined)result.edges=[edge('call',call.receiverCall)];
        else{
          const c=m.context(call.target)??m.uncertainContext(call.target);
          if(c?.members.join('.')==='db.query'){
            result.convex=true;result.uncertain=!!uncertainFor(c,kind=>kind==='query'||kind==='mutation');
          }else if(call.target.members.length===1&&m.bindings.has(call.target.binding)){
            result.edges=[edge('binding',call.target.binding)];result.uncertain=!!call.target.reassigned;
          }
        }
      }
    }
    return result;
  }
  return function summarizeQueryExecution(execution){
    // [index, filter, range, bounded, searchIndex, uncertain ownership]
    const pending=[{key:edge('call',execution.end),state:[0,0,0,0,0,0]}],visited=new Set();
    const locations={execution};let merged,foreign=false;
    const locate=(name,call)=>{if(!locations[name]||call.start<locations[name].start)locations[name]=call;};
    for(let cursor=0;cursor<pending.length;cursor++){
      const item=pending[cursor],node=origin(item.key),state=[...item.state],call=node.call;
      state[5] ||= Number(node.uncertain);
      if(call){
        const name=method(call);
        if(name==='withIndex'){const range=indexRange(call);state[2]=state[0]?join(state[2],range):range;state[0]=1;locate('index',call);}
        if(name==='filter'){state[1]=1;locate('filter',call);}
        if(['take','first','unique','paginate'].includes(name))state[3]=1;
        if(name==='withSearchIndex')state[4]=1;
      }
      const key=item.key+':'+state.join('');
      if(visited.has(key))continue;visited.add(key);
      if(node.convex){
        const result=[state[5]?2:1,...state.slice(0,5)];
        merged=merged?merged.map((v,i)=>join(v,result[i])):result;
      }else if(node.edges.length){
        for(const key of node.edges)pending.push({key,state});
      }else foreign=true;
    }
    if(!merged)return {convexOrigin:0,locations,execution:method(execution)};
    if(foreign)merged[0]=2;
    const [convexOrigin,index,filter,range,bounded,searchIndex]=merged;
    return {convexOrigin,index,filter,range,bounded,searchIndex,locations,execution:method(execution)};
  };
}
function checkQueryChains(ctx,file,facts,m){
  const summarizeQueryExecution=createQuerySummarizer(facts,m);
  const not=value=>value===2?2:1-value;
  const and=(...values)=>values.includes(0)?0:values.includes(2)?2:1;
  for(const execution of facts.calls){
    if(!['collect','take','first','unique','paginate'].includes(execution.target.members.at(-1)))continue;
    const s=summarizeQueryExecution(execution);if(s.convexOrigin===0)continue;
    const base=and(s.convexOrigin,not(s.searchIndex));
    function evaluate(rule,result,location,reason='unresolved-identity'){
      if(result===0)return;
      if(result===2)m.narrow(rule,location??execution,reason);
      else m.emit(rule,(location??execution).memberRange??location??execution);
    }
    // The checks share facts, not a mutually exclusive winner. Eligibility for
    // whole-set collect is intentionally narrower than indexed/filter reviews.
    evaluate('filter-table-scan',and(base,s.filter,not(s.index)),s.locations.filter);
    evaluate('index-without-range',and(base,s.index,not(s.range),not(s.bounded)),s.locations.index,s.convexOrigin===1&&s.index===1&&s.range===2?'unsupported-expression':'unresolved-identity');
    evaluate('index-filter-combo',and(base,s.index,s.filter),s.locations.filter);
    evaluate('unbounded-collect',and(base,not(s.index),not(s.filter),not(s.bounded),Number(s.execution==='collect')),s.locations.execution);
  }
}
'''.replace('RANGEBODY',rangebody)
s=s[:s.index('function checkQueryChains')]+new;p.write_text(s)
