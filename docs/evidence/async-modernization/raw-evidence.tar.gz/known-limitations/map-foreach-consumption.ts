const tasks=[1].map(async x=>x);tasks.forEach(async task=>{await task});
[1].map(async positive=>positive);