function f(url:string){fetch(url)}
fetch("/positive");