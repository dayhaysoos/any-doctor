from pathlib import Path
import json,hashlib,subprocess,re,shutil,tarfile,collections
R=Path('/Users/nickdejesus/Code/any-doctor');E=Path(Path('/tmp/any-doctor-async-repair-path').read_text());F=E/'review-candidate';P=F/'platform/candidate-package';A=Path('/private/tmp/any-doctor-async-audit-yct0odt8');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=load(F/'verification.json');pack=load(P/'verification.json');m=load(F/'working-files.json')
assert sha(Path(v['artifact']))==v['artifactSha256']
for row in m['files']:assert sha(R/row['file'])==row['sha256'],row['file']
assert load(F/'working-files-before.json')==m['files']
assert v['headContextOnly']=='2b8c937554cbe22f35a7695d38504c0ca253f244' and v['branch']=='website/docs'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==v['headContextOnly']
assert not subprocess.check_output(['git','diff','--name-only','b7615748884c738bf8ccc3aef06ef69daf223f02',v['headContextOnly']],cwd=R,text=True).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=R,check=True)
# Original runners, seed sources and labels are immutable.
for n in ['challenges.py','degraded.py','degraded-identifiers.py']:
 assert sha(A/n)==sha(E/n)==sha(F/n)
assert (F/'challenge-expectations.json').read_bytes()==(A/'challenge-expectations.json').read_bytes()
for p in (A/'seeds').glob('*.ts'):assert p.read_bytes()==(F/'seeds'/p.name).read_bytes()
for p in (E/'historical').iterdir():assert sha(p)==sha(A/p.name),p.name
snapshot=Path('/tmp/any-doctor-frozen-sift');actual={str(p.relative_to(snapshot)):sha(p) for p in snapshot.rglob('*') if p.is_file()}
manifest=load(R/'docs/evidence/consumer-analysis/sift-manifest.json');assert actual==load(E/'frozen-before.json')=={x['file']:x['sha256'] for x in manifest['files']}
for x in manifest['files']:assert (snapshot/x['file']).stat().st_size==x['bytes']
(E/'frozen-integrity.json').write_text(json.dumps({'files':len(actual),'manifestDigest':manifest['manifestDigest'],'missing':[],'extra':[],'changed':[],'beforeAndAfterIdentical':True},indent=2))
def findings(d):return sorted([dict(f,rule=c['rule'],severity=f.get('severity',c['severity'])) for g in d['groups'] for c in g['checks'] for f in c['findings']],key=lambda f:(f['rule'],f['file'],f['line'],f.get('column',-1)))
local=load(F/'repaired-local-sift.stdout');packed=load(F/'packed-sift.stdout');lf=findings(local);pf=findings(packed);assert lf==pf
base=load(E/'baseline-sift.stdout');assert base['counts']['warning']==18 and base['counts']['total']==18
assert local['fileCount']==packed['fileCount']==base['fileCount']==671 and not local['crashed'] and local['analysisAvailable']
key=lambda f:(f['rule'],f['file'],f['line']);baseline={key(f):f for f in findings(base)};current={key(f):f for f in lf};old={key(f):f for f in load(A/'sift-adjudications.json')};review=[]
for k in sorted(baseline.keys()|current.keys()):
 b=baseline.get(k);c=current.get(k);historical=old.get(k);status='retained' if b and c else 'removed' if b else 'added';rule,file,line=k
 if status=='removed':
  if historical['classification']=='false_positive':reason='Corrected timer false positive: returned native cleanup cancels the actual handle, including qualified calls and directly invoked local scheduler helpers.';classification='corrected_false_positive'
  elif historical['classification']=='unknown':reason='Forwarded Request/input and init remain unknown; absence of cancellation is not established. Scoped abstention.';classification='unknown'
  else:reason='Lost contextual review candidate: input provenance is unresolved by this bounded projection (URL constructor, runtime string guard, framework-produced URL, or typed object field). Source still supports reviewing cancellation. Count reduction is coverage loss, not evidence of a fix.';classification='missed_review_candidate'
 elif status=='added':
  if rule.startswith('fetch'):reason='Newly detected multiline signup request. No cancellation signal is present, but submission completion may be deliberate. Informational policy review, not a measured lifecycle bug.'
  else:reason='Timer in applyTheme is reached by the React effect and has no returned cleanup cancellation. Removing a transition class after 200ms is deliberate completion work; cancellation could leave the class behind. Review candidate, not authorization to add cleanup blindly.'
  classification='review_candidate'
 else:reason='The missing-signal observation remains; severity is informational and guidance asks for the intended cancellation/deadline contract, preserving server and extension semantics.';classification='review_candidate'
 lines=(snapshot/file).read_text().splitlines();excerpt='\n'.join(f'{i+1}: {lines[i]}' for i in range(max(0,line-6),min(len(lines),line+9)))
 review.append({'rule':rule,'file':file,'line':line,'status':status,'classification':classification,'reason':reason,'historical':historical,'before':b,'after':c,'sourceExcerpt':excerpt})
delta=dict(collections.Counter(r['status'] for r in review));assert delta=={'retained':7,'removed':11,'added':2},delta
assert sum(r['classification']=='corrected_false_positive' for r in review)==3
(E/'sift-source-review.json').write_text(json.dumps({'before':base['counts'],'after':local['counts'],'delta':delta,'localPackedIdentical':True,'rows':review},indent=2))
# Keep unrelated Convex and Slop output exactly stable against accepted evidence.
convexBefore=load(R/'docs/evidence/convex-modernization/frozen-comparison.json')
convex=load(F/'platform/local-convex-sift.stdout');convexPacked=load(F/'platform/packed-convex-sift.stdout');assert findings(convex)==findings(convexPacked)
previous=Path('/tmp/any-doctor-convex-modernization-path').read_text().strip();prev=Path(previous)/'review-candidate'
assert findings(convex)==findings(load(prev/'local-convex-sift.stdout'))
slop=load(F/'platform/local-slop-sift.stdout');slopPacked=load(P/'sift.stdout');assert findings(slop)==findings(slopPacked)==findings(load(prev/'local-slop-sift.stdout'))
# Final remaining-limit specimens, separate from passing regression labels.
limits=[]
for label,root in [('local',R),('packed',P/'consumer/node_modules/any-doctor')]:
 cmd=['node',str(root/'bin/cli.js'),'run',str(root/'doctors/async.mjs'),str(E/'remaining-limits'),'--format','json'];r=subprocess.run(cmd,cwd=root,capture_output=True,text=True);(E/(label+'-limits-scan.json')).write_text(r.stdout);(E/(label+'-limits.stderr')).write_text(r.stderr);assert r.returncode==0
 fs=findings(json.loads(r.stdout));rows=[]
 for c in load(E/'remaining-limits.json'):
  found=[x for x in fs if x['file']==c['name']+'.ts' and x['rule']==c['rule']];assert len(found)==c['expectedActual'],(label,c['name'],len(found));assert any(x['line']==2 for x in found)
  rows.append(dict(c,actual=found))
 obj={'label':label,'command':cmd,'exit':r.returncode,'knownGapCount':3,'positiveNeighborsPreserved':3,'rows':rows};limits.append(obj);(E/(label+'-limits-results.json')).write_text(json.dumps(obj,indent=2))
counts={label:dict(v['counts'][label]) for label in ['repaired-local','packed']}
ansi=re.compile(r'\x1b\[[0-9;]*m')
def bundle(p):
 t=ansi.sub('',p.read_text());return {'passed':len(re.findall(r'^\s+✔',t,re.M)),'failed':len(re.findall(r'^\s+✖',t,re.M)),'skipped':len(re.findall(r'^\s+–.*skipped:',t,re.M))}
counts['repaired-local']['bundledAll']=bundle(F/'platform/local-bundled.stdout');counts['packed']['bundledAll']=bundle(P/'bundled-discovery.stdout')
counts['packed']['asyncBundled']=pack['counts']['verify-async']
cmd=['node',str(R/'bin/cli.js'),'verify',str(R/'doctors/async.mjs')];r=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(E/'final-local-async.stdout').write_text(r.stdout);(E/'final-local-async.stderr').write_text(r.stderr);assert r.returncode==0
(E/'additional-command-ledger.json').write_text(json.dumps([{'command':cmd,'exit':r.returncode},{'command':['node',str(E/'platform-proof.mjs')],'exit':0}],indent=2))
counts['repaired-local']['asyncBundled']=bundle(E/'final-local-async.stdout');assert counts['repaired-local']['asyncBundled']==counts['packed']['asyncBundled']=={'passed':50,'failed':0,'skipped':0}
log=(F/'platform/final-tests.stdout').read_text();assert 'pass 565' in log and 'fail 0' in log;counts['automated']={'passed':565,'failed':0,'skipped':0}
for label in ['repaired-local','packed']:
 assert counts[label]['bundledAll']=={'passed':244,'failed':0,'skipped':15}
 d=load(F/(label+'-challenges-results.json'));counts[label]['independentPerRule']={rule:{'passed':sum(r['passed'] for r in d['results'] if r['rule']==rule),'failed':sum(not r['passed'] for r in d['results'] if r['rule']==rule),'skipped':0} for rule in sorted({r['rule'] for r in d['results']})}
(E/'final-counts.json').write_text(json.dumps(counts,indent=2))
start=load(E/'starting-state.json');owned={'src/call-structure.ts','src/contract.ts','bin/call-structure.js','bin/contract.d.ts','doctors/async.mjs','doctors/async.fixtures.mjs','docs/call-structure.md','docs-site/src/content/docs/doctors/async.mdx','test/cli.test.mjs','test/runner.test.mjs','test/dashboard-pty.test.mjs'}
external={'src/cli.ts','bin/cli.js','package.json','src/telemetry.ts','bin/telemetry.js','bin/telemetry.d.ts','test/telemetry.test.mjs','metrics/README.md','metrics/schema.sql','metrics/worker.js','metrics/wrangler.jsonc'}
changed=[]
for file,digest in start['files'].items():
 now=sha(R/file) if (R/file).is_file() else None
 if now!=digest:
  assert file in owned|external,file;changed.append({'file':file,'before':digest,'after':now,'owner':'Async repair' if file in owned else 'concurrent telemetry removal / generated rebuild'})
(E/'preservation.json').write_text(json.dumps({'branch':v['branch'],'headUnchanged':False,'startingHead':'b7615748884c738bf8ccc3aef06ef69daf223f02','finalHead':v['headContextOnly'],'headExplanation':'Concurrent telemetry commit and revert completed before final gates; net tracked tree diff empty. This repair created no commits.','indexEmpty':True,'unexpectedDrift':[],'frozenUnchanged':True,'historicalAuditUnchanged':True,'candidateStableAcrossAllGates':True,'changesSinceStart':changed},indent=2))
(E/'source-gates.json').write_text(json.dumps({'asyncCounts':counts,'convexIndependent':load(F/'platform/verification.json')['localChallenges'],'convexExtra':load(F/'platform/verification.json')['localExtra'],'convexFrozenUnchanged':len(findings(convex)),'slopFrozenUnchanged':len(findings(slop)),'consumerLabeled':pack['labeled'],'consumerScopes':pack['loaderScopes'],'consumerOriginal':pack['independent'],'consumerRepair':pack['repairChallenges'],'consumerCombination':pack['combination'],'consumerIsolation':pack['isolation'],'installedRuntimeFiles':len(pack['executableFiles']),'manifestFiles':len(m['files'])},indent=2))
print(json.dumps({'tarball':v['artifact'],'tarballSha256':v['artifactSha256'],'workingDigest':m['workingDigest'],'doctorSha256':v['doctorSha256'],'counts':counts,'sift':local['counts'],'delta':delta},indent=2))
