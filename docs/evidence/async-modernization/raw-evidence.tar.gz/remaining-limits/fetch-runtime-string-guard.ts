function f(url:unknown){if(typeof url!=="string")return;fetch(url)}
fetch("/positive");