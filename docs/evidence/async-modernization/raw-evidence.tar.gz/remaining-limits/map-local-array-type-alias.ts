type Numbers=number[];function f(xs:Numbers){xs.map(async x=>x)}
[1].map(async positive=>positive);