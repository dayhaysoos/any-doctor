export const fixtures = [
  {
    "name": "map-dropped-binding",
    "analysis": "off",
    "seed": {
      "src/example.ts": "const xs=[1,2];\nconst tasks=xs.map(async x=>x);"
    },
    "expected": [
      {
        "rule": "unawaited-async-map",
        "file": "src/example.ts",
        "line": 2
      }
    ]
  },
  {
    "name": "map-combined",
    "analysis": "off",
    "seed": {
      "src/example.ts": "const xs=[1,2];\nconst tasks=xs.map(async x=>x); await Promise.all(tasks);"
    },
    "expected": []
  },
  {
    "name": "map-returned-binding",
    "analysis": "off",
    "seed": {
      "src/example.ts": "const xs=[1,2];\nexport function f(){ const tasks=xs.map(async x=>x); return tasks; }"
    },
    "expected": []
  },
  {
    "name": "map-per-element-await",
    "analysis": "off",
    "seed": {
      "src/example.ts": "const xs=[1,2];\nconst tasks=xs.map(async x=>x); for (const task of tasks) { await task; }"
    },
    "expected": []
  },
  {
    "name": "map-nested-array-combiner",
    "analysis": "off",
    "seed": {
      "src/example.ts": "const xs=[1,2];\nconst tasks=xs.map(async x=>x); await Promise.all([tasks]);"
    },
    "expected": [
      {
        "rule": "unawaited-async-map",
        "file": "src/example.ts",
        "line": 2
      }
    ]
  },
  {
    "name": "map-unrelated-scope-combiner",
    "analysis": "off",
    "seed": {
      "src/example.ts": "const xs=[1,2];\nconst tasks=xs.map(async x=>x); function other(){ const tasks=[]; return Promise.all(tasks); }"
    },
    "expected": [
      {
        "rule": "unawaited-async-map",
        "file": "src/example.ts",
        "line": 2
      }
    ]
  }
];
