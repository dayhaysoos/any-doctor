import {createRequire} from "module";const r=createRequire(import.meta.url);const resolve=(r[("resolve" as const)] as typeof r.resolve)!;console.log(resolve("./target.ts"));
