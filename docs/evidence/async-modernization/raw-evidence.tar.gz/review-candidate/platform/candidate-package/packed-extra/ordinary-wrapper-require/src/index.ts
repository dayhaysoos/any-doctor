const require=(((v:string)=>v) as (v:string)=>string)!; console.log((require as Function)("./target.ts"));
