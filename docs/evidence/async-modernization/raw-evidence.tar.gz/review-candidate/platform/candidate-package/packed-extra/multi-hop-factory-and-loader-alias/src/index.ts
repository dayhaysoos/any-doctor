import {createRequire as make} from "node:module"; const a=make; const b=(a as typeof make);const r=b(import.meta.url);const s=r;const t=(s as typeof r)!; console.log(t("./target.ts").helper());
