import {createRequire} from "module";const r=createRequire(import.meta.url);const load=Date.now()>0 ? (r as typeof r) : ((v:string)=>v);console.log((load("./target.ts") as any).helper());
