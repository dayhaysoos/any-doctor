export function another(){return 43;}
