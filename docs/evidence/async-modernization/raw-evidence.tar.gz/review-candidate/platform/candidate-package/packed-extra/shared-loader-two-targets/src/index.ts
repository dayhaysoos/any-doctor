import {createRequire} from "module";const load=createRequire(import.meta.url);console.log(load("./target.ts").helper(),load("./second.ts").another());
