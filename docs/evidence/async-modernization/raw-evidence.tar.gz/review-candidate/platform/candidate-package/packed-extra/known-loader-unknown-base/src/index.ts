import {createRequire} from "module";const r=createRequire(new URL("../other/base.mjs",import.meta.url));console.log(r("./dead.ts"));
