import * as mod from "module";const key=process.argv[2];const r=(mod as any)[key](import.meta.url);r("./target.ts");
