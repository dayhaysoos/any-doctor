declare const ordinary: (v:string)=>string;console.log(ordinary("./target.ts"));
