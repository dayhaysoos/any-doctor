import pathlib,json,subprocess,sys
OUT=pathlib.Path(__file__).resolve().parent
CASES=[]
def add(name,rule,expected,source,reason): CASES.append(dict(name=name,rule=rule,expected=expected,source=source,reason=reason))
imp='import { query, mutation, action, internalMutation } from "./_generated/server";\nimport { v } from "convex/values";\n'
def handler(kind,body,param='ctx'): return imp+f'export const f = {kind}({{\nargs: {{}},\nhandler: async ({param}) => {{\n{body}\n}}\n}});\n'
for rule,body in [('unbounded-collect','return ctx.db.query("events").collect();'),('filter-table-scan','return ctx.db.query("events").filter(q => q.eq(q.field("status"), "failed")).take(50);'),('index-without-range','return ctx.db.query("events").withIndex("by_status").collect();'),('index-filter-combo','return ctx.db.query("events").withIndex("by_status", q => q.eq("status", "failed")).filter(q => q.eq(q.field("owner"), "me")).take(50);')]:
 add(rule+'-positive',rule,1,handler('query',body),'Direct Convex chain matches the published pattern.')
 add(rule+'-renamed-context',rule,1,handler('query',body.replace('ctx.','context.'),'context'),'Renaming the real handler parameter does not change the query.')
 add(rule+'-local-lookalike',rule,0,'const db = { query() { return { collect(){return []}, filter(){return this}, take(){return []}, withIndex(){return this} } } };\nexport function f(){'+body.replace('ctx.db','db')+'}\n','This is a synchronous local object, not a Convex database.')
add('bounded-query','unbounded-collect',0,handler('query','return ctx.db.query("events").take(50);'),'Explicitly bounded positive control for abstention.')
add('array-filter','filter-table-scan',0,handler('query','return [1,2,3].filter(x => x > 1);'),'Ordinary array filter.')
add('index-range','index-without-range',0,handler('query','return ctx.db.query("events").withIndex("by_status", q => q.eq("status", "failed")).collect();'),'Actual range must remain recognized.')
add('index-dead-branch-range','index-without-range',1,handler('query','return ctx.db.query("events").withIndex("by_status", q => { if (false) return q.eq("status", "failed"); return q; }).collect();'),'Unreachable eq call does not restrict the returned range.')
add('validator-missing','missing-args-validator',1,imp+'export const f = query({ handler: async (ctx,args) => args });','Object configuration genuinely lacks args.')
add('validator-before','missing-args-validator',0,handler('query','return 1;'),'Usual valid configuration.')
add('validator-after','missing-args-validator',0,imp+'export const f = query({ handler: async (ctx,args) => args, args: { title: v.string() } });','Object property order does not disable validation.')
add('validator-shorthand','missing-args-validator',0,imp+'const args = {title:v.string()};\nexport const f = query({args, handler: async (ctx,args) => args});','Shorthand property supplies the validator object.')
add('validator-async-direct','missing-args-validator',1,imp+'export const f = query(async (ctx,args) => args);','Supported direct async function form has no validator.')
add('validator-alias-missing','missing-args-validator',1,'import {query as read} from "./_generated/server";\nexport const f = read({handler:async (ctx,args)=>args});','Import alias remains a Convex query.')
add('validator-local-lookalike','missing-args-validator',0,'import { v } from "convex/values";\nconst query = options => options;\nexport const f = query({handler:()=>v.string()});','Unrelated local function in a file using Convex values.')
add('validator-comment-import','missing-args-validator',0,'// import { v } from "convex/values";\nconst query = options => options;\nexport const f = query({handler:()=>1});','Comment cannot establish framework import identity.')
for rule,kind,body in [('write-in-query','query','await ctx.db.patch("id", {title:"x"});'),('db-in-action','action','return await ctx.db.get("id");')]:
 add(rule+'-positive',rule,1,handler(kind,body),'Forbidden real context API.')
 add(rule+'-one-line',rule,1,imp+f'export const f = {kind}({{args:{{}},handler:async(ctx)=>{{{body}}}}});','Formatting does not change forbidden API use.')
 add(rule+'-renamed-context',rule,1,handler(kind,body.replace('ctx.','context.'),'context'),'Parameter name does not change context API.')
 fake='const ctx = { db: { async patch(){return null}, async get(){return null} } };\n'+body
 add(rule+'-shadowed-context',rule,0,handler(kind,'{\n'+fake+'\n}'),'Block-local ctx is an ordinary object, not the handler parameter.')
add('discard-positive','unawaited-convex-call',1,handler('mutation','ctx.db.patch("id", {title:"x"});'),'Known promise result discarded.')
add('discard-unrelated-promise-all','unawaited-convex-call',1,handler('mutation','ctx.db.patch("id", {title:"x"});\nawait Promise.all([]);'),'Original regression: unrelated await must not hide discarded patch.')
add('discard-consumed-promise-all','unawaited-convex-call',0,handler('mutation','await Promise.all([ctx.db.patch("id", {title:"x"})]);'),'The actual promise is consumed.')
add('discard-renamed-context','unawaited-convex-call',1,handler('mutation','context.db.patch("id", {title:"x"});','context'),'Binding-aware check should survive rename.')
add('discard-shadowed-context','unawaited-convex-call',0,handler('mutation','{ const ctx = { db: { patch(){ return null } } }; ctx.db.patch(); }'),'Ordinary synchronous shadowed object.')
add('query-clock-positive','query-clock-reactivity',1,handler('query','return Date.now();'),'Direct global query clock.')
add('query-clock-action','query-clock-reactivity',0,handler('action','return Date.now();'),'Action clock is allowed.')
add('query-clock-shadowed','query-clock-reactivity',0,handler('query','const Date = {now:()=>123}; return Date.now();'),'Local Date object is not wall clock.')
add('transaction-duration-positive','transaction-clock-duration',1,handler('mutation','const start=Date.now(); await ctx.db.get("id"); return Date.now()-start;'),'Fixed transaction clock cannot measure elapsed duration.')
add('transaction-duration-action','transaction-clock-duration',0,handler('action','const start=Date.now(); await ctx.runQuery({}); return Date.now()-start;'),'Action duration is meaningful.')
add('transaction-duration-historical','transaction-clock-duration',0,handler('mutation','const row=await ctx.db.get("id"); return Date.now()-row.createdAt;'),'Historical timestamp difference is valid.')
add('node-runtime-positive','node-runtime-transaction',1,'"use node";\n'+handler('mutation','return 1;'),'Transaction in Node file.')
add('node-runtime-action','node-runtime-transaction',0,'"use node";\n'+handler('action','return 1;'),'Action in Node file allowed.')
add('node-runtime-no-semicolon','node-runtime-transaction',1,'"use node"\n'+handler('mutation','return 1;'),'Valid directive with automatic semicolon insertion.')
add('node-runtime-block-comment','node-runtime-transaction',1,'/* license */\n"use node";\n'+handler('mutation','return 1;'),'A leading comment is not a statement.')
add('presence-positive','presence-patch-on-shared-document',1,handler('mutation','await ctx.db.patch("userId", {lastSeen:Date.now()});'),'Canonical presence candidate; actual fanout remains unknown.')
add('presence-local-lookalike','presence-patch-on-shared-document',0,'const model = {patch(id, value){return value}}; model.patch(1, {lastSeen:123});','Non-Convex method must not get database invalidation advice.')
add('presence-segmented','presence-patch-on-shared-document',0,imp+'export const f=mutation({args:{heartbeatId:v.id("heartbeats")},handler:async(ctx,args)=>{await ctx.db.patch(args.heartbeatId,{lastSeen:Date.now()});}});','Already uses dedicated heartbeats table, the recommended fix and documented lookalike.')
add('spread-positive','spread-into-patch',1,handler('mutation','await ctx.db.patch("id", {...payload});'),'Syntactic patch spread candidate; payload ownership unknown.')
add('spread-local-lookalike','spread-into-patch',0,'const model={patch(id,value){return value}}; const fields={title:"x"}; model.patch(1,{...fields});','Ordinary object method, no Convex DB or client.')
add('spread-explicit-fields','spread-into-patch',0,handler('mutation','await ctx.db.patch("id", {title:"x"});'),'Explicit field patch.')
add('spread-server-owned-candidate','spread-into-patch',1,handler('mutation','const fields={title:"server literal"}; await ctx.db.patch("id", {...fields});'),'Pattern is present but client-controlled-fields security advice is unsupported.')
add('spread-nested-call','spread-into-patch',1,handler('mutation','const fields={title:"x"}; await ctx.db.patch("id", {updatedAt:Date.now(), ...fields});'),'Earlier nested call must not hide a later spread in the same patch.')
add('public-api-positive','public-api-in-server-call',1,handler('action','await ctx.runQuery(api.users.current, {});'),'Public namespace candidate; alone not an authorization defect.')
add('public-api-internal-negative','public-api-in-server-call',0,handler('action','await ctx.runQuery(internal.users.current, {});'),'Internal reference.')
add('public-api-local-lookalike','public-api-in-server-call',0,'import { v } from "convex/values";\nconst api={users:{current:1}}; const ctx={runQuery(x){return x}}; ctx.runQuery(api.users.current);','Names are local ordinary objects.')
add('sequential-positive','sequential-run-in-loop',1,handler('action','for(const id of ids){\n await ctx.runMutation(internal.rows.update, {id});\n}'),'Actual awaited loop, candidate only.')
add('sequential-already-parallel','sequential-run-in-loop',0,handler('action','const pending=[];\nfor(const id of ids){\n pending.push(ctx.runMutation(internal.rows.update, {id}));\n}\nawait Promise.all(pending);'),'Calls start without serial awaits and Promise.all consumes them.')
add('sequential-query-loop','sequential-run-in-loop',1,handler('action','for(const id of ids){\n await ctx.runQuery(internal.rows.get, {id});\n}'),'Published claim is awaited run*; runQuery in action also makes separate calls.')
add('sequential-local-lookalike','sequential-run-in-loop',0,'import { v } from "convex/values";\nconst ctx={runMutation(x){return x}};\nfor(const id of [1,2]){\n ctx.runMutation(id);\n}','Local synchronous method has no transactions.')

def main():
 label=sys.argv[1]; base=pathlib.Path(sys.argv[2]).resolve(); seedroot=OUT/'seeds'; seedroot.mkdir(exist_ok=True)
 for c in CASES:
  f=seedroot/(c['name']+'.ts')
  if f.exists(): assert f.read_text()==c['source'],'Seed drift'
  else: f.write_text(c['source'])
 seedfile=OUT/'challenge-expectations.json'; data=json.dumps(CASES,indent=2)
 if seedfile.exists(): assert seedfile.read_text()==data,'Expectation drift'
 else: seedfile.write_text(data)
 cmd=['node',str(base/'bin/cli.js'),'run',str(base/'doctors/convex.mjs'),str(seedroot),'--format','json'];p=subprocess.run(cmd,cwd=base,capture_output=True)
 (OUT/f'{label}-challenges-scan.json').write_bytes(p.stdout);(OUT/f'{label}-challenges.stderr').write_bytes(p.stderr)
 d=json.loads(p.stdout); finds=[dict(f,rule=c['rule']) for g in d['groups'] for c in g['checks'] for f in c['findings']];results=[]
 for c in CASES:
  actual=[f for f in finds if f['file']==c['name']+'.ts' and f['rule']==c['rule']]; results.append({**{k:v for k,v in c.items() if k!='source'},'actual':len(actual),'passed':len(actual)==c['expected'],'findings':actual})
 summary={'label':label,'command':cmd,'exit':p.returncode,'passed':sum(r['passed'] for r in results),'failed':sum(not r['passed'] for r in results),'skipped':0,'results':results}; (OUT/f'{label}-challenges-results.json').write_text(json.dumps(summary,indent=2)); print(label,summary['passed'],summary['failed']);print('\n'.join(f"FAIL {r['name']} expected={r['expected']} actual={r['actual']}" for r in results if not r['passed']))
if __name__=='__main__':main()
