const settle=Promise.all.bind(Promise);const a=[1].map(async x=>x);settle(a);
[1].map(async positive=>positive);