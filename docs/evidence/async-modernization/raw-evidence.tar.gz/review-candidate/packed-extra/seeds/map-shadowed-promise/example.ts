const Promise={all:async a=>a.length};const a=[1].map(async x=>x);await Promise.all(a);
[1].map(async positive=>positive);