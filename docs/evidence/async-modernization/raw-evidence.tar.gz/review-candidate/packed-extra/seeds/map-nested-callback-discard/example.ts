Promise.all([1].map(async()=>{[1].map(async x=>x)}));
[1].map(async positive=>positive);