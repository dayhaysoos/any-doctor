import {useEffect as effect} from "react";effect(()=>{const start=()=>setTimeout(()=>{},1)},[])
import {useEffect as positiveEffect} from "react"; positiveEffect(()=>{setTimeout(()=>{},1)},[]);