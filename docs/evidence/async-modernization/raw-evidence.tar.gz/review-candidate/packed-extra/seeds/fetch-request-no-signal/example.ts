fetch(new Request("/"));
fetch("/positive");