function work(){const a=[1].map(async x=>x);const b=a;return b}
[1].map(async positive=>positive);