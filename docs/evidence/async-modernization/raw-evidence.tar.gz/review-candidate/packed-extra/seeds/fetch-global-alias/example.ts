const request=globalThis.fetch;request("/");
fetch("/positive");