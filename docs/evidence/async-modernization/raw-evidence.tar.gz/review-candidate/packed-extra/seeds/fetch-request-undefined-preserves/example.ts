const c=new AbortController();fetch(new Request("https://example.invalid",{signal:c.signal}),{signal:undefined});
fetch("/positive");