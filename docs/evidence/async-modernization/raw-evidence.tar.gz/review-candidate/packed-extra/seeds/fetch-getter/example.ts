fetch("/",{get signal(){return external}});
fetch("/positive");