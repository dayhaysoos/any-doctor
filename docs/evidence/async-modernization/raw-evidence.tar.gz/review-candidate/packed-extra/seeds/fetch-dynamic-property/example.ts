function f(key){fetch("/",{[key]:external})}
fetch("/positive");