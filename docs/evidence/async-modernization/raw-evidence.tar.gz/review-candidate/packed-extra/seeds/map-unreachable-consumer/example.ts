const a=[1].map(async x=>x);if(false)Promise.all(a);
[1].map(async positive=>positive);