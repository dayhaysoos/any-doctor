type Array<T>={map:(cb:any)=>void};function f(xs:Array<number>){xs.map(async x=>x)}
[1].map(async positive=>positive);