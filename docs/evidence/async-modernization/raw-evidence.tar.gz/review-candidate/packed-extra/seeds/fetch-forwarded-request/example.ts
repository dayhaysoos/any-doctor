function f(input:Request){fetch(input)}
fetch("/positive");