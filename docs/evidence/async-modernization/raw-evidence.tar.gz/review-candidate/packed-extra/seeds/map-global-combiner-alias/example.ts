const p=globalThis.Promise;const a=[1].map(async x=>x);await p["all"](a);
[1].map(async positive=>positive);