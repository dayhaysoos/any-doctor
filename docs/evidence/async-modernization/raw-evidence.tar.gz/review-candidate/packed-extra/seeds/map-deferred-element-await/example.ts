const a=[1].map(async x=>x);for(const task of a){const later=async()=>await task}
[1].map(async positive=>positive);