function f(){const a=[1].map(async x=>x);return {a}}
[1].map(async positive=>positive);