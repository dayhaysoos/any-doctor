function f(key){fetch("/",{[key]:external,signal:null})}
fetch("/positive");