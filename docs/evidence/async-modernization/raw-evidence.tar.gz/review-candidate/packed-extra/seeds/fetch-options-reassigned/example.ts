let options={};options=external;fetch("/",options);
fetch("/positive");