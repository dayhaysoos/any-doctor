import * as React from "react";function f(React){React.useEffect(()=>setTimeout(()=>{},1))}
import {useEffect as positiveEffect} from "react"; positiveEffect(()=>{setTimeout(()=>{},1)},[]);