let a=[1].map(async x=>x);a=[];Promise.all(a);
[1].map(async positive=>positive);