function f(id){fetch(`/api/${id}`)}
fetch("/positive");