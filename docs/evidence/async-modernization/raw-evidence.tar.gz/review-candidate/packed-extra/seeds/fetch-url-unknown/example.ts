function f(input){fetch(input)}
fetch("/positive");