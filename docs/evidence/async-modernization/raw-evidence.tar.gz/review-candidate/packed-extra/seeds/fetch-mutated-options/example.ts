const options={};options.signal=external;fetch("/",options);
fetch("/positive");