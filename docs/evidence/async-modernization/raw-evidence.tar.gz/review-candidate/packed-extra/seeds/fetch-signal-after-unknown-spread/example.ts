const c=new AbortController();function f(init){fetch("/",{...init,signal:c.signal})}
fetch("/positive");