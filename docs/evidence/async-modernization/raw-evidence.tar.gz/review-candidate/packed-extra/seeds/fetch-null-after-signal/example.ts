const c=new AbortController();fetch("/",{signal:c.signal,signal:null});
fetch("/positive");