const a=[1].map(async x=>x);for(const task of a){await {task}}
[1].map(async positive=>positive);