function ignore(tasks){return 1}const a=[1].map(async x=>x);ignore(a);
[1].map(async positive=>positive);