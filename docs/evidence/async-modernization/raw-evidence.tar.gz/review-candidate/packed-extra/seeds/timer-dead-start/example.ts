import {useEffect as effect} from "react";effect(()=>{if(false)setTimeout(()=>{},1)},[])
import {useEffect as positiveEffect} from "react"; positiveEffect(()=>{setTimeout(()=>{},1)},[]);