const a=([1] as number[])!.map(async x=>x);const b=(a satisfies Promise<number>[]);Promise.all(b);
[1].map(async positive=>positive);