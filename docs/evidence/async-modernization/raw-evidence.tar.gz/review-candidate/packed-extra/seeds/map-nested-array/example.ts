const a=[1].map(async x=>x);await Promise.all([a]);
[1].map(async positive=>positive);