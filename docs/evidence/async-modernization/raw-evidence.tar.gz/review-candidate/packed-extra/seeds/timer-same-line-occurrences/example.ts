import {useEffect as effect} from "react";effect(()=>{setTimeout(()=>{},1);setTimeout(()=>{},1)},[])
import {useEffect as positiveEffect} from "react"; positiveEffect(()=>{setTimeout(()=>{},1)},[]);