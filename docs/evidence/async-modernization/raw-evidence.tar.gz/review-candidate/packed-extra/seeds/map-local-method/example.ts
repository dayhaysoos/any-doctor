const obj={map:async cb=>cb(1)};obj.map(async x=>x);
[1].map(async positive=>positive);