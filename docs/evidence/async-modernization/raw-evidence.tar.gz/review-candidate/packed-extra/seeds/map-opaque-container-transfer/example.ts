const a=[1].map(async x=>x);consume({a});
[1].map(async positive=>positive);