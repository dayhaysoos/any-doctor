const options={};configure(options);fetch("/",{...options});
fetch("/positive");