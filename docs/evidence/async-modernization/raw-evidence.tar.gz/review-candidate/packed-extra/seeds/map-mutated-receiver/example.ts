const xs=[1];xs.map=other;xs.map(async x=>x);
[1].map(async positive=>positive);