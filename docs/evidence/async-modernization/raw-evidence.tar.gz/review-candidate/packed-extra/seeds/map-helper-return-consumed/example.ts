function echo(a){return a}const a=[1].map(async x=>x);const b=echo(a);Promise.all(b);
[1].map(async positive=>positive);