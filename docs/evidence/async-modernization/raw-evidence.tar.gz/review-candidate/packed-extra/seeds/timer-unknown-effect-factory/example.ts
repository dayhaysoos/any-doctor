const effect=getEffect();effect(()=>setTimeout(()=>{},1));
import {useEffect as positiveEffect} from "react"; positiveEffect(()=>{setTimeout(()=>{},1)},[]);