const c=new AbortController();function f(init){fetch("/",{signal:c.signal,...init})}
fetch("/positive");