function f(xs:ReadonlyArray<number>){xs.map(async x=>x)}
[1].map(async positive=>positive);