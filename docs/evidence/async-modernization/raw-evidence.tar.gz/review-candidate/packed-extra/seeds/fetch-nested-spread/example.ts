const c=new AbortController();const a={signal:c.signal};const b={...a};fetch("/",{...b});
fetch("/positive");