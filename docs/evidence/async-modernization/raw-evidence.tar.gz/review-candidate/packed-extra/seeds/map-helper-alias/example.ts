async function settle(tasks){const a=tasks;return Promise.all(a)}const a=[1].map(async x=>x);settle(a);
[1].map(async positive=>positive);