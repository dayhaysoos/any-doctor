const fn=()=>{[1].map(async x=>x)};Promise.all([fn]);
[1].map(async positive=>positive);