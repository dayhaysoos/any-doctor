const c=new AbortController();fetch("/",{/*before*/["signal"]:c.signal});
fetch("/positive");