const xs=[1];configure(xs);xs.map(async x=>x);
[1].map(async positive=>positive);