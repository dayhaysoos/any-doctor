const c=new AbortController();fetch("/",{signal:null,signal:c.signal});
fetch("/positive");