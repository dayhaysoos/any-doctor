const a=[1].map(async x=>x);externalConsumer(a);
[1].map(async positive=>positive);