[1].filter(Boolean).slice().map(async x=>x);
[1].map(async positive=>positive);