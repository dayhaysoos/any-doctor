function echo(a){return a}const a=[1].map(async x=>x);echo(a);
[1].map(async positive=>positive);