function f(globalThis){globalThis.fetch("/")}
fetch("/positive");