import assert from "node:assert/strict";
const c=new AbortController();const r=new Request("https://example.invalid",{signal:c.signal});
const inherited=new Request(r,{signal:undefined}), disconnected=new Request(r,{signal:null});c.abort();
assert.equal(inherited.signal.aborted,true);assert.equal(disconnected.signal.aborted,false);
let finish;const p=new Promise(resolve=>finish=resolve);let settled=false;p.then(()=>settled=true);
const nested=await Promise.all([[p]]);assert.equal(settled,false);assert.equal(nested[0][0],p);
const object=await {p};assert.equal(settled,false);assert.equal(object.p,p);finish();await p;
console.log(JSON.stringify({node:process.version,requestUndefinedPreserves:true,requestNullDisconnects:true,nestedArrayDoesNotSettle:true,awaitObjectDoesNotSettleFields:true,networkCalls:0}));
