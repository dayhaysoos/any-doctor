# Independent Async doctor review

Verdict: keep the doctor, but improve all three checks before presenting it as a trusted default. Its bundled fixtures pass while independent cases expose both false alarms and missed positives. Do not treat current suggestions as instructions for autonomous edits. An opt-in experimental release with explicit limitations is a narrower claim than acceptance as a reliable default.

## Exact candidate and scope

Repository: `/Users/nickdejesus/Code/any-doctor`, branch `website/docs`, audit-start HEAD `b7615748884c738bf8ccc3aef06ef69daf223f02`. This was an uncommitted working-files audit, not a HEAD-only or published-package audit. Node: `v26.5.0`.

Doctor: `doctors/async.mjs`, SHA-256 `92607b8fbd8f5d83b430a1439cd04ed563b63884b3d5e1cbeedf87856b2fec72`.

Preserved package: `packed/any-doctor-0.1.2.tgz`, SHA-256 `3c9a124898f607e8b11d25881042635cc5352fbde579e04891a8025d4a6b7a1b`. Packed with `npm pack --ignore-scripts`, then installed by canonical absolute path into a fresh temporary consumer using `npm install --ignore-scripts --no-audit --no-fund`. All 86 runnable package files checked match the audit-start manifest; installed files also match the archive. This captures the existing runnable CLI rather than claiming a fresh rebuild of every TypeScript source file.

Concurrent edits changed Convex and shared analysis files while local checks ran. `integrity-after.json` lists those nine paths. Local observations are therefore not certification of the final evolving working tree. The immutable packed candidate is the reproducible reference; it independently reproduced the local outcomes below. This reviewer did not change repository source, stage, commit, push, or publish.

Frozen Sift: `/tmp/any-doctor-frozen-sift`; 1,530 files verified against `docs/evidence/consumer-analysis/sift-manifest.json` before and after testing. Digest `336f413f63936775224d5f9c8c1f5ba9abe9a465c9ef300fba93fac3657797f2`. No changed, missing, or extra files. Live Sift was not modified.

## Results

| Suite | Local observations passed / failed / skipped | Fixed installed package passed / failed / skipped |
| --- | --- | --- |
| Bundled Async verification | 41 / 0 / 3 | 41 / 0 / 3 |
| Independent behavioral cases | 22 / 33 / 0 | 22 / 33 / 0 |
| Independent location probes | 0 / 2 / 0 | 0 / 2 / 0 |
| Reduced-analysis authored cases, literal receivers | 3 / 3 / 0 | 3 / 3 / 0 |
| Reduced-analysis authored cases, named receivers | 2 / 4 / 0 | 2 / 4 / 0 |

Bundled verification includes 40 doctor fixtures and one shared innocent-corpus check. Its three skips are legacy location-coverage checks: none of the three rules declares `reportingUnit`.

Behavioral cases are deliberately adversarial, not a representative random sample or an estimate of customer error rate. The 33 failures comprise 18 false alarms or unsupported assertions and 15 missed positives. Some missing forms are already documented limitations; the aggregate tests the desired supported behavior, not solely regressions. Per rule: fetch 5 passed/13 failed; map 11/11; timer 6/9.

Bundled verification and scans exited zero. The independent runner also exited zero even with 33 failed expectations; its JSON counts were inspected explicitly. Each reduced-analysis verification exited one. Those suites additionally include a shared innocent-corpus pass and three legacy coverage skips in their raw logs; the table counts only their six authored cases per suite.

Local and packed frozen scans both produced 18 warnings across 671 eligible files: 15 fetch, three timer, zero map. Normalized findings match; group ordering differs. Neither scan reported a crash or partial analysis. The score of 99/Excellent measures the tool's scoring behavior, not the correctness of the findings.

## Frozen Sift adjudication

All 18 findings were inspected against source. Classification: **3 false positives, 2 unknown, 13 review candidates, zero confirmed bugs established by this audit**. Full individual judgments are in `sift-adjudications.json`; source excerpts are in `finding-contexts.md`.

All three timer warnings are false positives:

- `src/components/ChatWidget.tsx:1045`: assigns `window.setTimeout` to a handle and returns cleanup calling `window.clearTimeout` on that handle.
- `src/routes/dashboard.tsx:81`: same correct qualified timer/cleanup pattern.
- `src/lib/useTypewriterCycle.ts:80`: scheduler updates the shared timer handle; effect cleanup sets its cancellation flag and calls `window.clearTimeout(timerId)`.

The fetch findings in `extensions/sift-chrome/popup.ts:1484` and `:1504` forward caller-provided `input` and `init`. A Request or RequestInit may carry cancellation; this check does not establish absence. These are unknown, not proven missing signals.

The other 13 fetch findings lack an explicit signal but are spread across server routes, extension code, file downloads, telemetry/email clients, and QA utilities. Cancellation or deadlines may be useful, especially for network downloads. The scan has not established a lifecycle bug in each call, and its generic component-cleanup advice is inappropriate as a universal fix. A local packaged build-info fetch is especially low priority. Keep these as contextual policy-review candidates rather than confirmed defects.

## Repairs needed

### Timer: bind the API, handle, and returned cleanup

The current regex recognizes `window.setTimeout` but fails to associate its assignment with the handle because the assignment matcher encounters `window.` before `setTimeout`. This explains the actual Sift false positives.

Use structural calls and bindings to distinguish React effects and native timer APIs from local lookalikes. Trace the actual returned cleanup and the exact handle binding. A same-named clear call in an uncalled helper or a different scope is not cleanup. Support qualified globals, React import aliases, and concise callback bodies where feasible; report uncertainty where analysis cannot prove the relationship. Preserve positives for demonstrably uncancelled timers.

Independent witnesses include `timer-window-cleanup`, `timer-globalthis-cleanup`, `timer-local-effect-lookalike`, `timer-local-timer-lookalike`, `timer-local-clear-lookalike`, `timer-shadowed-handle`, `timer-unused-clear-helper`, `timer-concise-effect`, and `timer-alias-effect`.

### Map: prove consumption of the mapped promises

Containment inside a combiner expression or an enclosing variable initializer does not prove that the mapped promises reach the combiner. `Promise.all([tasks])` and `Promise.all([tasks.length])` do not settle elements of `tasks`; an inner discarded map inside an outer callback is also not consumed by the outer combiner. Shadowed `Promise.all` must not be assumed native.

Conversely, a returned array, an alias passed to a combiner, a helper that actually settles it, or iteration that awaits elements should not trigger a categorical unconsumed warning. A local object method named `map` need not return an array of promises. Follow value relationships and argument roles rather than names or enclosing spans. Treat unknown transfers as uncertainty instead of asserting loss. Sequential guidance must show an actual sequential await loop; simply removing `async` is not a sufficient general repair.

Independent witnesses include `map-returned-binding`, `map-helper-consumption`, `map-aliased-consumption`, `map-for-await`, `map-nested-array-combiner`, `map-combiner-unrelated-callback`, `map-length-in-combiner`, `map-shadowed-combiner`, `map-await-object-containing-element`, `map-local-object-method`, and `map-const-enclosing-function`.

### Fetch: separate missing evidence from an actual missing signal

Resolve the global fetch API before applying network advice. Account for Request-carried signals, known options variables, static spreads, computed keys, comments, and property override order. A key with value `undefined` or `null` does not provide caller cancellation. Forwarded options of unknown contents are not evidence that cancellation is absent.

Even when absence is proved, cancellation is a contextual policy recommendation unless a harmful lifecycle or timeout condition is established. Wording and severity must reflect that distinction.

Independent witnesses include `fetch-options-variable`, `fetch-spread-options`, `fetch-request-object`, `fetch-inline-request`, `fetch-forwarded-init`, both fetch lookalikes, `fetch-signal-undefined`, `fetch-signal-null`, `fetch-computed-signal`, `fetch-comment-before-signal`, and `fetch-overridden-signal`. `fetch-global-member` also exercises a declared coverage gap.

### Adopt the newer authoring and evaluation contract

Declare the correct reporting unit and verify exact occurrences, including multiple calls on one line. The map check currently emits column 1 for a call starting at zero-based column 0; the timer check omits columns for two distinct calls on the same line.

The map check declares binding needs and `onUnknown: "narrow"`, but its regex fallback is not reliably conservative. Under `analysis: "off"`, equivalent literal and named receiver cases diverge, valid consumers are flagged, and real dropped arrays can be missed. Use a defensibly narrow path or explicit unavailable/uncertain coverage rather than silently replacing identity with file-wide name matching. Keep unrelated positive controls to prevent broad suppression from masquerading as correctness.

These observations primarily call for modernizing the doctor. Shared capabilities are available, but cannot make a regex-based doctor's semantic assumptions correct automatically. If a missing shared capability is required, reproduce it separately and keep the platform change bounded; this audit does not certify or indict the concurrently edited shared implementation.

## Reproduction and retained evidence

The evidence directory is `/private/tmp/any-doctor-async-audit-yct0odt8`. Copy runners to a **new** directory before rerunning; they write outputs beside themselves. Preserve this corpus and its expectations.

```sh
AUDIT_NEXT=$(mktemp -d /private/tmp/any-doctor-async-retest-XXXXXX)
cp /private/tmp/any-doctor-async-audit-yct0odt8/challenges.py "$AUDIT_NEXT/challenges.py"
python3 "$AUDIT_NEXT/challenges.py" local /Users/nickdejesus/Code/any-doctor
python3 "$AUDIT_NEXT/challenges.py" retained-packed /private/tmp/any-doctor-async-audit-yct0odt8/consumer/node_modules/any-doctor
```

Inspect `failed` as well as process status. The 55 standalone scanner seeds and reasons are retained in `seeds/` and `challenge-expectations.json`. Copy `degraded.py` and `degraded-identifiers.py` to the new directory and run each with a distinct label and package-root argument for the reduced-analysis probes. These scripts copy the exact doctor into temporary fixtures and do not repair it.

`runtime-proof.mjs` and `runtime-proof.json` independently execute Request cancellation propagation, nested-array Promise.all behavior, and five timer/cleanup scenarios. No network requests were made. Timer probes use instrumented APIs and invoke returned cleanup; they are not mounted React/browser tests.

The location expectation for the two-timer witness was corrected from hand-counted columns 14/36 to actual starts 15/38. Original runner/results and the explicit correction are retained (`challenges-initial.py`, `*-initial-location-results.json`, `location-expectation-correction.json`). Both candidates were rerun after correction; both still fail because columns are absent. No behavioral expectation was relaxed.

Additional evidence: `summary.json`, `provenance.json`, `commands.json`, `additional-commands.json`, `baseline-artifact-integrity.json`, `packed-integrity.json`, `integrity-after.json`, `scan-comparison.json`, local/packed verification logs and scan JSON, and local/packed challenge-results JSON.

## Coverage limits and acceptance

This is an Async-only evaluation, not the full npm test suite or an all-doctor release gate. It combines one frozen real project, source inspection, targeted synthetic cases, reduced-analysis cases, packed-artifact testing, and small runtime witnesses. Historical Async failure classes were recreated from the earlier audit notes; the original temporary seed corpus was unavailable, so this is not an unchanged replay of that old corpus. No live application/browser behavior, provider calls, publication, or cross-version Node/browser compatibility was tested.

Acceptance: **not accepted as a trusted default in this candidate**. The patterns are worth detecting, and positive controls show useful capability, but the real-project timer false positives, unsupported fetch claims, missed map consumption defects, and unsafe fallback need correction. Retest unchanged expectations and source-adjudicated real findings against a newly bound artifact before changing that verdict. Do not advertise 100% correctness from green self-authored fixtures.

Primary semantic references: [Request.signal](https://developer.mozilla.org/en-US/docs/Web/API/Request/signal), [Promise.all](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/all), and [React useEffect cleanup](https://react.dev/reference/react/useEffect). These support the language/API semantics; the observed detector behavior comes from the retained runs.
