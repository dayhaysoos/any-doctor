import fs from 'node:fs';
import vm from 'node:vm';
const base = new URL('.', import.meta.url);
const controller = new AbortController();
const request = new Request('https://example.invalid', {signal:controller.signal});
controller.abort();
let resolveTask;
let settled = false;
const tasks = [new Promise(resolve => { resolveTask = () => { settled = true; resolve(1); }; })];
await Promise.all([tasks]);
const nestedArrayStillPending = !settled;
resolveTask();
await Promise.all(tasks);
const timerResults = {};
for (const name of ['timer-cleanup','timer-window-cleanup','timer-globalthis-cleanup','timer-shadowed-handle','timer-unused-clear-helper']) {
  const active = new Set(); let next=1;
  const env = {setTimeout: () => { const id=next++;active.add(id);return id; }, clearTimeout: id => active.delete(id)};
  env.window=env;env.globalThis=env;
  let cleanup;
  env.useEffect = setup => {cleanup=setup();};
  const source=fs.readFileSync(new URL('seeds/'+name+'.ts',base),'utf8').replace('import {useEffect} from "react";','');
  vm.runInNewContext(source,env);
  const before=active.size;if(typeof cleanup==='function') cleanup();
  timerResults[name]={activeBeforeCleanup:before,activeAfterCleanup:active.size};
}
const result={node:process.version,requestCarriesAbortedSignal:request.signal.aborted,nestedArrayStillPending,timerResults,note:'No network request made. Timer probe executes the authored snippets with instrumented timer functions and calls returned cleanup; it is not a mounted React/browser test.'};
fs.writeFileSync(new URL('runtime-proof.json',base),JSON.stringify(result,null,2));console.log(result);
