from pathlib import Path
import hashlib,json,subprocess,collections
p=Path(__file__).resolve().parent;r=Path('/Users/nickdejesus/Code/any-doctor');s=Path('/tmp/any-doctor-frozen-sift')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=r).decode().split('\0');after={f:sha(r/f) for f in files if f and (r/f).is_file()};before=json.loads((p/'working-before.json').read_text());drift=[f for f in set(before)|set(after) if before.get(f)!=after.get(f)];(p/'working-after.json').write_text(json.dumps(after,indent=2));m=json.loads((r/'docs/evidence/consumer-analysis/sift-manifest.json').read_text());expected={f['file'] for f in m['files']};actual={str(f.relative_to(s)) for f in s.rglob('*') if f.is_file()};snapDrift=[f['file'] for f in m['files'] if not (s/f['file']).is_file() or sha(s/f['file'])!=f['sha256'] or (s/f['file']).stat().st_size!=f['bytes']];integrity={'workingCount':len(after),'workingDrift':sorted(drift),'snapshotCount':len(expected),'snapshotDrift':snapDrift,'snapshotExtra':sorted(actual-expected),'snapshotMissing':sorted(expected-actual)};(p/'integrity-after.json').write_text(json.dumps(integrity,indent=2))
scan=json.loads((p/'local-scan.stdout').read_text());rows=[]
for g in scan['groups']:
 for c in g['checks']:
  for f in c['findings']:
   row={'rule':c['rule'],**{k:v for k,v in f.items() if k!='decisionKey'}}
   if c['rule']=='uncleared-settimeout-in-effect':row.update(classification='false_positive',reason='Source returns cleanup calling window.clearTimeout on the actual handle. Member-qualified setTimeout breaks the detector assignment lookup. Typewriter also sets cancelled=true.')
   elif f['file']=='extensions/sift-chrome/popup.ts' and f['line'] in [1484,1504]:row.update(classification='unknown',reason='Wrapper forwards input and caller-supplied RequestInit unchanged. The call may receive a Request signal or init.signal; absence of cancellation is not established.')
   else:row.update(classification='review_candidate',reason='Source has no explicit signal at this call. Cancellation/timeout policy can be useful but no user-facing lifecycle failure or timeout was measured; server, extension, QA and packaged-asset requests have different requirements.')
   rows.append(row)
(p/'sift-adjudications.json').write_text(json.dumps(rows,indent=2));summary={'provenance':json.loads((p/'provenance.json').read_text()),'packedProvenance':json.loads((p/'packed-integrity.json').read_text()),'integrity':integrity,'scan':json.loads((p/'scan-comparison.json').read_text()),'sourceAdjudications':dict(collections.Counter(x['classification'] for x in rows))}
for label in ['local','packed']:
 d=json.loads((p/f'{label}-challenges-results.json').read_text());byrule={}
 for x in d['results']:
  byrule.setdefault(x['rule'],{'passed':0,'failed':0,'falseAlarms':0,'missedPositives':0});byrule[x['rule']]['passed' if x['passed'] else 'failed']+=1
  if not x['passed']:byrule[x['rule']]['falseAlarms' if x['expected']==0 else 'missedPositives']+=1
 summary[label]={'bundled':{'passed':41,'failed':0,'skipped':3},'behavioral':{k:d[k] for k in ['passed','failed','skipped','exit']},'perRule':byrule,'locations':{'passed':sum(x['passed'] for x in d['locations']),'failed':sum(not x['passed'] for x in d['locations']),'skipped':0},'degradedLiteral':json.loads((p/f'{label}-degraded-results.json').read_text()),'degradedIdentifier':json.loads((p/f'{label}-identifier-degraded-results.json').read_text())}
(p/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:summary[k] for k in ['packedProvenance','integrity','sourceAdjudications']},indent=2));print(json.dumps(summary['local'],indent=2))
