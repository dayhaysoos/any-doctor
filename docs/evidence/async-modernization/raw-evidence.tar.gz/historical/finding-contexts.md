
## fetch-calls-without-abortsignal src/routes/api/kit/subscribe.ts:146
142:             return jsonResponse({ error: "Kit integration not configured" }, 500);
143:           }
144: 
145:           // Step 1: Create the subscriber
146:           const createResponse = await fetch(
147:             "https://api.kit.com/v4/subscribers",
148:             {
149:               method: "POST",
150:               headers: {
151:                 "Content-Type": "application/json",
152:                 "X-Kit-Api-Key": kitApiKey,
153:               },
154:               body: JSON.stringify({
155:                 email_address,
156:                 first_name: first_name || undefined,
157:               }),
158:             }

## fetch-calls-without-abortsignal src/routes/api/kit/subscribe.ts:176
172: 
173:           // Step 2: Add tag based on role
174:           const tagId = ROLE_TAG_IDS[role];
175:           if (tagId && subscriberId) {
176:             const tagResponse = await fetch(
177:               `https://api.kit.com/v4/tags/${tagId}/subscribers`,
178:               {
179:               method: "POST",
180:               headers: {
181:                 "Content-Type": "application/json",
182:                 "X-Kit-Api-Key": kitApiKey,
183:               },
184:               body: JSON.stringify({
185:                 email_address,
186:               }),
187:               }
188:             );

## fetch-calls-without-abortsignal src/routes/api/kit/subscribe.ts:199
195:             }
196:           }
197: 
198:           // Step 3: Add subscriber to double opt-in form (triggers incentive email)
199:           const formResponse = await fetch(
200:             `https://api.kit.com/v4/forms/${KIT_FORM_ID}/subscribers`,
201:             {
202:               method: "POST",
203:               headers: {
204:                 "Content-Type": "application/json",
205:                 "X-Kit-Api-Key": kitApiKey,
206:               },
207:               body: JSON.stringify({
208:                 email_address,
209:               }),
210:             }
211:           );

## fetch-calls-without-abortsignal src/routes/api/resumes/$applicationId.ts:74
70:   if (rangeHeader) {
71:     requestHeaders.set("Range", rangeHeader);
72:   }
73: 
74:   const response = await fetch(targetUrl, {
75:     headers: requestHeaders,
76:     method: "GET",
77:     redirect: "manual",
78:   });
79: 
80:   if (isHeadRequest) {
81:     return new Response(null, {
82:       status: response.status,
83:       headers: buildProxyHeaders(response.headers),
84:     });
85:   }
86: 

## fetch-calls-without-abortsignal extensions/sift-chrome/src/api/client.ts:69
65:   path: string,
66:   args: Record<string, unknown>
67: ): Promise<T> {
68:   const endpoint = `${normalizeConvexUrl(convexUrl)}/api/${kind}`;
69:   const response = await fetch(endpoint, {
70:     method: "POST",
71:     headers: {
72:       "Content-Type": "application/json",
73:     },
74:     body: JSON.stringify({ path, args }),
75:   });
76: 
77:   let payload: ConvexEnvelope<T> | null = null;
78:   try {
79:     const parsed = await response.json();
80:     payload = isRecord(parsed) ? (parsed as ConvexEnvelope<T>) : null;
81:   } catch {

## fetch-calls-without-abortsignal extensions/sift-chrome/background.ts:89
85:   convexUrl: string;
86:   pairingCode: string;
87:   extensionName: string;
88: }): Promise<PairingExchangeResult> {
89:   const response = await fetch(`${normalizeUrl(convexUrl)}/api/mutation`, {
90:     method: "POST",
91:     headers: {
92:       "Content-Type": "application/json",
93:     },
94:     body: JSON.stringify({
95:       path: "extensionAuth:exchangePairingCode",
96:       args: {
97:         pairingCode,
98:         extensionName,
99:       },
100:     }),
101:   });

## fetch-calls-without-abortsignal extensions/sift-chrome/popup.ts:305
301:   const buildInfoUrl = runtime?.getURL?.("build-info.json");
302:   if (!buildInfoUrl) return null;
303: 
304:   try {
305:     const response = await fetch(buildInfoUrl, { cache: "no-store" });
306:     if (!response.ok) return null;
307:     const payload = (await response.json()) as unknown;
308:     if (!isRecord(payload)) return null;
309:     return {
310:       version: typeof payload.version === "string" ? payload.version : undefined,
311:       fingerprint: typeof payload.fingerprint === "string" ? payload.fingerprint : undefined,
312:       gitCommit: typeof payload.gitCommit === "string" ? payload.gitCommit : undefined,
313:       gitDirty: typeof payload.gitDirty === "boolean" ? payload.gitDirty : undefined,
314:       generatedAt: typeof payload.generatedAt === "string" ? payload.generatedAt : undefined,
315:       fileCount: typeof payload.fileCount === "number" ? payload.fileCount : undefined,
316:     };
317:   } catch {

## fetch-calls-without-abortsignal extensions/sift-chrome/popup.ts:1405
1401:       if (typeof targetUrl !== "string" || !targetUrl) {
1402:         return { ok: false, error: "Invalid target URL." };
1403:       }
1404:       try {
1405:         const response = await fetch(targetUrl, {
1406:           method: "GET",
1407:           credentials: "include",
1408:         });
1409:         if (!response.ok) {
1410:           return {
1411:             ok: false,
1412:             status: response.status,
1413:             error: `Failed to fetch attachment (${response.status})`,
1414:           };
1415:         }
1416: 
1417:         const buffer = await response.arrayBuffer();

## fetch-calls-without-abortsignal extensions/sift-chrome/popup.ts:1484
1480:     const isDetectedDownloadRequest =
1481:       method === "GET" && selectedDetectedUrls.has(requestUrl);
1482: 
1483:     if (!isDetectedDownloadRequest) {
1484:       return fetch(input, init);
1485:     }
1486: 
1487:     onDetectedDownloadRequest?.(requestUrl);
1488: 
1489:     const tryPageContextFallback = async (): Promise<Response> => {
1490:       if (!activeTabId) {
1491:         throw new Error("Missing active tab context for fallback fetch.");
1492:       }
1493:       onFallbackFetch?.(requestUrl);
1494:       appendDebugLog(`Trying page-context fetch fallback for ${requestUrl}.`);
1495:       const fallbackResponse = await fetchDetectedAttachmentViaPageContext(
1496:         activeTabId,

## fetch-calls-without-abortsignal extensions/sift-chrome/popup.ts:1504
1500:       return fallbackResponse;
1501:     };
1502: 
1503:     try {
1504:       const directResponse = await fetch(input, init);
1505:       if (directResponse.ok) {
1506:         return directResponse;
1507:       }
1508: 
1509:       appendDebugLog(
1510:         `Direct fetch returned HTTP ${directResponse.status}: ${requestUrl}`
1511:       );
1512:       if (!activeTabId) {
1513:         return directResponse;
1514:       }
1515: 
1516:       try {

## fetch-calls-without-abortsignal convex/analysis/extractText.ts:118
114:     if (!fileUrl) {
115:       throw new Error("Could not get URL for resume file");
116:     }
117: 
118:     const response = await fetch(fileUrl);
119:     if (!response.ok) {
120:       throw new Error(`Failed to fetch resume: ${response.statusText}`);
121:     }
122: 
123:     const arrayBuffer = await response.arrayBuffer();
124: 
125:     // 3. Server-side file validation
126:     // Extension and manual_upload bulk: 10MB; candidate self-upload: 512KB
127:     const maxSize = resumeAnalysisMaxSizeForSource(app.source);
128:     if (arrayBuffer.byteLength > maxSize) {
129:       throw new Error(
130:         `File too large: ${(arrayBuffer.byteLength / 1024).toFixed(

## fetch-calls-without-abortsignal convex/devApplicationFileUploadQa.ts:326
322:       uploadToken: string;
323:     };
324: 
325:     const fileName = `qa-resume-${suffix}.pdf`;
326:     const uploadResponse = await fetch(issued.uploadUrl, {
327:       method: "POST",
328:       headers: { "Content-Type": "application/pdf" },
329:       body: new Blob(
330:         [
331:           `%PDF-1.4
332: 1 0 obj
333: << /Type /Catalog >>
334: endobj
335: trailer
336: << /Root 1 0 R >>
337: %%EOF
338: QA resume upload ${suffix}

## fetch-calls-without-abortsignal convex/devApplicationFileUploadQa.ts:493
489:       uploadToken: string;
490:     };
491: 
492:     const fileName = `qa-duplicate-attempt-${suffix}.pdf`;
493:     const uploadResponse = await fetch(issued.uploadUrl, {
494:       method: "POST",
495:       headers: { "Content-Type": "application/pdf" },
496:       body: new Blob([`%PDF-1.4\nQA duplicate cleanup ${suffix}\n%%EOF\n`], {
497:         type: "application/pdf",
498:       }),
499:     });
500:     if (!uploadResponse.ok) {
501:       throw new Error(
502:         `Convex storage upload failed (${uploadResponse.status} ${uploadResponse.statusText})`,
503:       );
504:     }
505:     const uploaded = (await uploadResponse.json()) as {

## fetch-calls-without-abortsignal convex/lib/emailClient.ts:30
26:   apiKey: string,
27:   options: SendEmailOptions,
28: ): Promise<SendEmailResult> {
29:   try {
30:     const response = await fetch("https://api.resend.com/emails", {
31:       method: "POST",
32:       headers: {
33:         Authorization: `Bearer ${apiKey}`,
34:         "Content-Type": "application/json",
35:       },
36:       body: JSON.stringify({
37:         from: options.from,
38:         to: options.to,
39:         subject: options.subject,
40:         html: options.html,
41:         ...(options.replyTo ? { reply_to: options.replyTo } : {}),
42:       }),

## fetch-calls-without-abortsignal convex/lib/langfuse.ts:254
250: export async function fetchOpenRouterGenerationRest(params: {
251:   id: string;
252:   apiKey: string;
253: }): Promise<OpenRouterGenerationRestPayload["data"] | undefined> {
254:   const response = await fetch(
255:     `https://openrouter.ai/api/v1/generation?id=${encodeURIComponent(params.id)}`,
256:     {
257:       headers: {
258:         Authorization: `Bearer ${params.apiKey}`,
259:         "Content-Type": "application/json",
260:       },
261:     }
262:   );
263:   if (!response.ok) return undefined;
264:   const payload = (await response.json()) as OpenRouterGenerationRestPayload;
265:   return payload.data;
266: }

## uncleared-settimeout-in-effect src/components/ChatWidget.tsx:1045
1041:     if (!pending || !messages?.length || isLoading) return;
1042: 
1043:     const now = Date.now();
1044:     if (now < pending.checkAfter) {
1045:       const timeout = window.setTimeout(() => {
1046:         setResponseCheckTick((tick) => tick + 1);
1047:       }, pending.checkAfter - now);
1048:       return () => window.clearTimeout(timeout);
1049:     }
1050: 
1051:     if (
1052:       !lastUserMessageId ||
1053:       pending.userMessageIdBeforeSend === lastUserMessageId
1054:     ) {
1055:       return;
1056:     }
1057: 

## uncleared-settimeout-in-effect src/lib/useTypewriterCycle.ts:80
76:     let phraseIndex = 0;
77:     let deleting = false;
78: 
79:     const schedule = (fn: () => void, ms: number) => {
80:       timerId = window.setTimeout(() => {
81:         if (!cancelled) fn();
82:       }, ms);
83:     };
84: 
85:     const tick = () => {
86:       const phrase = phrases[phraseIndex] ?? "";
87: 
88:       if (!deleting) {
89:         if (charIndex < phrase.length) {
90:           charIndex += 1;
91:           setDisplayText(phrase.slice(0, charIndex));
92:           schedule(tick, typeIntervalMs);

## uncleared-settimeout-in-effect src/routes/dashboard.tsx:81
77:     if (!isAppLoading) {
78:       setShowBootSpinner(false);
79:       return;
80:     }
81:     const timeout = window.setTimeout(() => {
82:       setShowBootSpinner(true);
83:     }, 180);
84:     return () => window.clearTimeout(timeout);
85:   }, [isAppLoading]);
86: 
87:   useEffect(() => {
88:     if (!isAuthenticated || !user?.id || isLoading) return;
89:     const email = (user as { email?: string })?.email;
90:     if (profile === null) {
91:       getOrCreateProfile({ betterAuthUserId: user.id, email });
92:     } else if (profile && !profile.email && email) {
93:       getOrCreateProfile({ betterAuthUserId: user.id, email });