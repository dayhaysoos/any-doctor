/*license*/
"use node"
import {query,mutation,action,internalMutation} from "./_generated/server"; import {v} from "convex/values"; query({args:{},handler:async context=>1}); mutation({args:{},handler:async context=>1});