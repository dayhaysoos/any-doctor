const key="../target"; console.log((await import(`./plugins/${key}.ts`)).helper());
