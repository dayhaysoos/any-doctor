const key="present"; await import(`./plugins/${key}/../../target.ts`);
