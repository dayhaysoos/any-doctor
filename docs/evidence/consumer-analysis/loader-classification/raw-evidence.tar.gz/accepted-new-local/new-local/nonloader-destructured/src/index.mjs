const {require}={require:x=>x};console.log(require(process.argv[2]));
