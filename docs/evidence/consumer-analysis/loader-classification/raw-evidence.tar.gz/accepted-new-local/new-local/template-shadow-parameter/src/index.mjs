const key="present"; function run(key){return import(`./plugins/${key}.ts`);} run(process.argv[2]);
