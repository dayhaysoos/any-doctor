export const dead=13;
