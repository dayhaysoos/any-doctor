let key="present"; key=process.argv[2]; await import(`./plugins/${key}.ts`);
