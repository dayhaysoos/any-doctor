function f(require){return require("./target.ts");}console.log(f(x=>x));
