import {createRequire as make} from "module"; const load=make(import.meta.url); console.log(load("./target.ts").helper());
