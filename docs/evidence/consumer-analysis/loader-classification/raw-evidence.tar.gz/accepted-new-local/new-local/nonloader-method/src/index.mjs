const x={require(v){return v;}};console.log(x.require("./target.ts"));
