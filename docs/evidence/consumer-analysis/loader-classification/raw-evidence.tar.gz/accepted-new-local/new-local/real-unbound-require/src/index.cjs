console.log(require("./target.ts").helper());
