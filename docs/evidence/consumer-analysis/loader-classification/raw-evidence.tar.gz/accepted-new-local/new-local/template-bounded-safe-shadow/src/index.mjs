const key="../target"; { const key="present"; await import(`./plugins/${key}.ts`); }
