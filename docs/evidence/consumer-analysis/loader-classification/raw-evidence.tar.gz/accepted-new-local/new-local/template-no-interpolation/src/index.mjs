console.log((await import(`./plugins/../target.ts`)).helper());
