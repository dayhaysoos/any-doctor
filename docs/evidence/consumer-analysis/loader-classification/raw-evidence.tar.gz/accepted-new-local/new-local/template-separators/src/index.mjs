const key="sub/../../target"; console.log((await import(`./plugins/${key}.ts`)).helper());
