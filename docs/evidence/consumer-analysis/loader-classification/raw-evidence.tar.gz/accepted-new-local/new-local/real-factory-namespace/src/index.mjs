import * as mod from "node:module"; const load=mod.createRequire(import.meta.url); console.log(load("./target.ts").helper());
