import {helper} from "@lib/tool";helper();
