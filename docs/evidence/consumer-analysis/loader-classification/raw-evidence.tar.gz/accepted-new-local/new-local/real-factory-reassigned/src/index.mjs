import {createRequire} from "node:module";let require=createRequire(import.meta.url);require=globalThis.loader;require("./target.ts");
