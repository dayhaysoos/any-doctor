const require=x=>x;console.log(require("./target.ts"));
