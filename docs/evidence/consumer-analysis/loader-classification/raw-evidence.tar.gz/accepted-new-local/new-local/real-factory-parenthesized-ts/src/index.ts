import {createRequire} from "node:module";const require=(createRequire(import.meta.url) as ReturnType<typeof createRequire>);console.log(require("./target.ts").helper());
