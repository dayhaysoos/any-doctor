import {createRequire} from "node:module";const require=createRequire(new URL("../other/base.mjs",import.meta.url));console.log(require("./dead.ts"));
