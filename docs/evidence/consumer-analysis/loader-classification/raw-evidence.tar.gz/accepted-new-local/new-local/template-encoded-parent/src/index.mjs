const key="%2e%2e/target"; console.log((await import(`./plugins/${key}.ts`)).helper());
