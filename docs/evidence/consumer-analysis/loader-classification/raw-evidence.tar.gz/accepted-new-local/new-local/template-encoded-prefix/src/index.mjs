const key="target"; await import(`./plugins/%2e%2e/${key}.ts`);
