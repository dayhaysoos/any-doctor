import mod from "node:module";const require=mod.createRequire(import.meta.url);console.log(require("./target.ts").helper());
