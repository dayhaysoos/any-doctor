import {scale as a} from "./a"; import {scale as b} from "./b"; console.log(a([]),b([]));
