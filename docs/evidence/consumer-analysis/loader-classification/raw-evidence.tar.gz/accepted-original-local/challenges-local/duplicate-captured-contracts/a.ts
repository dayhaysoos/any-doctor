const factor=2; export function scale(xs: number[]) { const out=[]; const offset=1; for(const x of xs) { out.push(x*factor+offset); } return out; }
