export function work(v: string) { const text = v.trim(); if (!text) return ""; const changed = text.replaceAll(String.raw`a\nb`, "x"); return changed.toLowerCase(); }
