type T = typeof import("./a").helper; const x: T = () => 42; console.log(x);
