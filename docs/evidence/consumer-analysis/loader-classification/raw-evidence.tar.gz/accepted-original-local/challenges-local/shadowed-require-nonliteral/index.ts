function require(value:string){ return value; } const name="nothing"; console.log(require(name));
