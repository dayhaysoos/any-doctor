import {publicHelper} from "./index"; console.log(publicHelper());
