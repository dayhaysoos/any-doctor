const suffix="pple"; (await import(`./plugins/a${suffix}.ts`)).helper();
