let ns = await import("./a"); ns = other; sink(ns);
