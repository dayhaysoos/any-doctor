function require(value:string){ return value; } console.log(require("./a"));
