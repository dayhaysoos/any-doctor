export function helper() { return 42; }
export const unused=0;
