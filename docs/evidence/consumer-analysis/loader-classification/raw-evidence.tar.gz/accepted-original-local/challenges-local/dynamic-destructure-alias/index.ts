const {helper: run}=await import("./a"); run();
