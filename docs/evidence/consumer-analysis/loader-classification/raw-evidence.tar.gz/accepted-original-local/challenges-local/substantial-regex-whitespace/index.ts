import {work as a} from "./a"; import {work as b} from "./b"; console.log(a("x"),b("x"));
