export function work(v: string) { const text = v.trim(); if (!text) return ""; const changed = text.replace(/ab/g, "x"); return changed.toLowerCase(); }
