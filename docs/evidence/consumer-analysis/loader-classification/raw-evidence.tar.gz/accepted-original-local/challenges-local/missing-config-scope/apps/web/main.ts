import {helper} from "@shared/tool"; helper();
