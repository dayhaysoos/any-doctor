import {helper as unusedAlias} from "./a"; console.log("hello");
