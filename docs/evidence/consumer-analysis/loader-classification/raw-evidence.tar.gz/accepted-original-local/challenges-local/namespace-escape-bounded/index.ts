import * as a from "./a"; sink(a);
