import {helper} from "./b"; console.log(helper());
