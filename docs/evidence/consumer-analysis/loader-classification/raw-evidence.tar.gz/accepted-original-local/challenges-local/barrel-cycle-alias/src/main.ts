import {action} from "./barrel2"; action();
