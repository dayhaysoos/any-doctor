export * from "./barrel2"; export {helper as action} from "./a";
