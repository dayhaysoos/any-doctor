import * as ui from "./ui"; export default function Page(){return <ui.Widget/>;} function local(ui:any){return ui.Unused();} console.log(local);
