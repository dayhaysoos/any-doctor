import Page from "./page"; console.log(Page);
