export function orphanA() { return 41; }
