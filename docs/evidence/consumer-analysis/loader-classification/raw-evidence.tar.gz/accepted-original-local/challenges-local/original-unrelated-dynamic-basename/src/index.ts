import("./b/helper").then(m => console.log(m.usedB()));
