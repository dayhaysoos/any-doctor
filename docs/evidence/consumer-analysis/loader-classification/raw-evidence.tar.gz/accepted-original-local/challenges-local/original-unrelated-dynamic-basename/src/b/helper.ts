export function usedB() { return 42; }
