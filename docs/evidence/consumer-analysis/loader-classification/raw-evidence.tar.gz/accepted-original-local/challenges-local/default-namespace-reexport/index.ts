import {ns} from "./barrel"; console.log(ns.default());
