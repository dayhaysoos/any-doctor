export default function helper(){return 42;} export const spare=3;
