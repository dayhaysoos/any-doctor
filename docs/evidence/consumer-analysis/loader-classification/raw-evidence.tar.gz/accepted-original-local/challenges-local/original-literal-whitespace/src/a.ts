export function normalizeLabel(v: string) { return v.trim().replaceAll("a b", "x"); }
