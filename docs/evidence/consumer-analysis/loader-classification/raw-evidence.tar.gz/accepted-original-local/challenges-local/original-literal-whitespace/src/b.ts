export function normalizeLabel(v: string) { return v.trim().replaceAll("ab", "x"); }
