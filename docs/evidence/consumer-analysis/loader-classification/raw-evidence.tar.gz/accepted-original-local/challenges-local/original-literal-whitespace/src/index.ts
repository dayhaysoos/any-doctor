import {normalizeLabel as a} from "./a"; import {normalizeLabel as b} from "./b"; console.log(a("a b"),b("a b"));
