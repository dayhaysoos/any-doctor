export function work(v: string) { const text = v.trim(); if (!text) return ""; const changed = text.replaceAll("ab", "x"); return changed.toLowerCase(); }
