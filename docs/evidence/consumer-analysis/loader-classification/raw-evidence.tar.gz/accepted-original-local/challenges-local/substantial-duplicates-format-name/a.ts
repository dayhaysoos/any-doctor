export function work(v: string) { const text = v.trim(); if (!text) return ""; const changed = text.replaceAll("a b", "x"); return changed.toLowerCase(); }
