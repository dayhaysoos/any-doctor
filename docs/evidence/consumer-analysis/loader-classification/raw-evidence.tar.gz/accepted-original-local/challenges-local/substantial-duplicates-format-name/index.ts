import {work} from "./a"; import {other} from "./b"; console.log(work("x"),other("x"));
