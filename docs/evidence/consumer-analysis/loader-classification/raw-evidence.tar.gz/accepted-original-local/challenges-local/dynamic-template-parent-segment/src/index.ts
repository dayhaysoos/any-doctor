const name="../utility"; const mod = await import(`./plugins/${name}.ts`); console.log(mod.helper());
