import {helper} from "./a"; export const generatedResult=helper();
