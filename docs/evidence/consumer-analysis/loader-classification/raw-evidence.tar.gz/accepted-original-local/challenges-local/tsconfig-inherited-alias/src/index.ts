import {helper} from "@lib/a"; helper();
