import {helper} from "./helpers"; console.log(helper());
