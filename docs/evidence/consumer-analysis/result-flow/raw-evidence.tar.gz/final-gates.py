import pathlib,json,hashlib,re,subprocess,difflib
R=pathlib.Path('/Users/nickdejesus/Code/any-doctor');E=pathlib.Path('/private/tmp/any-doctor-result-flow-repair');P=E/'candidate-packed';load=lambda p:json.loads(p.read_text());write=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks={}
for label,base in [('local',E),('packed',P)]:
 paths={'labeled':base/('local-labeled.json' if label=='local' else 'labeled.json'),'scopes':base/('local-scopes.json' if label=='local' else 'loader-scopes.json'),'original':base/('local-original/local-independent-challenges.json' if label=='local' else 'packed-independent-challenges.json'),'repair':base/('local-repair/local-new-challenges.json' if label=='local' else 'packed-new-challenges.json'),'combination':base/('local-combination/local-extra-results.json' if label=='local' else 'packed-extra-results.json')}
 checks[label]={}
 for name,p in paths.items():
  d=load(p);counts={k:d[k] for k in ['passed','failed','skipped']};checks[label][name]=counts
  expected={'labeled':(164,0,0),'scopes':(84,0,0),'original':(29,1,0),'repair':(32,1,0),'combination':(12,0,0)}[name];assert tuple(counts.values())==expected,(label,name,counts)
  if name in ['original','repair']:
   failed=[r['name'] for r in d['rows'] if not r['passed']];assert failed==(['mts-authored-positive'] if name=='original' else ['inherited-cts']);checks[label][name]['failedNames']=failed
  if name=='combination':
   runtimes=[r['runtime'] for r in d['rows'] if 'runtime' in r];assert len(runtimes)==10 and all(r['exitCode']==0 for r in runtimes);checks[label][name]['runtimeWitnessesPassed']=10
log=(E/'candidate-tests.log').read_text();assert all(re.search(r'ℹ '+x+r' '+str(n)+r'\b',log) for x,n in [('tests',551),('pass',551),('fail',0),('skipped',0)]);checks['local']['automated']={'passed':551,'failed':0,'skipped':0}
pv=load(P/'verification.json');checks['local']['isolation']=pv['isolation']['local'];checks['packed']['isolation']=pv['isolation']['packed']
for label,p in [('local',E/'local-verify.stdout'),('packed',P/'bundled-discovery.stdout')]:
 s=re.sub(r'\x1b\[[0-9;]*m','',p.read_text());c={'passed':len(re.findall(r'^\s+✔',s,re.M)),'failed':len(re.findall(r'^\s+✖',s,re.M)),'skipped':len(re.findall(r'^\s+–.*skipped:',s,re.M))};assert c=={'passed':228,'failed':0,'skipped':18},c;checks[label]['bundled']=c
assert all(r['status']==0 for r in load(E/'local-commands.json'));assert all(r['status']==0 for r in pv['runs'])
# Full frozen bytes and exact retained findings/coverage, with time excluded only.
m=load(R/'docs/evidence/consumer-analysis/sift-manifest.json');root=pathlib.Path(m['snapshot']);actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()};expected={r['file'] for r in m['files']};drift=[r['file'] for r in m['files'] if sha(root/r['file'])!=r['sha256'] or (root/r['file']).stat().st_size!=r['bytes']];assert not drift and actual==expected;write(E/'frozen-after.json',{'files':len(expected),'drift':drift,'extra':sorted(actual-expected),'missing':sorted(expected-actual),'manifestDigest':m['manifestDigest']})
baseline=load(R/'docs/evidence/consumer-analysis/sift-after.json')
def findings(d):return sorted([dict(f,rule=c['rule']) for g in d['groups'] for c in g['checks'] for f in c['findings']],key=lambda f:json.dumps(f,sort_keys=True))
def coverage(d):return [{k:v for k,v in g['analysisCoverage'].items() if k!='durationMs'} for g in d['groups']]
frozen={}
for label,p in [('local',E/'local-sift.stdout'),('packed',P/'sift.stdout')]:
 d=load(p);assert not d['crashed'] and not d['broken'];assert findings(d)==findings(baseline);assert coverage(d)==coverage(baseline);count=len(findings(d));issues=sum(len(g['analysisCoverage']['issues']) for g in d['groups']);assert count==67 and issues==20;frozen[label]={'findings':count,'coverageIssues':issues,'exactFindingsMatch':True,'exactCoverageExceptDurationMatch':True,'crashed':0,'broken':0}
write(E/'frozen-comparison.json',frozen)
# Reproductions, preserving original seeds and expectations.
before=load(E/'before-isolation/result-flow-isolation.json');after=load(P/'isolation-review/result-flow-isolation.json')
for row in after:
 b=next(b for b in before if (b['name'],b['label'])==(row['name'],row['label']));assert b['expected']==row['expected']
 for f in ['src/index.ts','src/target.ts','other/dead.ts']:assert (pathlib.Path(b['seedDirectory'])/f).read_bytes()==(pathlib.Path(row['seedDirectory'])/f).read_bytes()
assert sum(r['passed'] for r in before)==4 and sum(r['passed'] for r in after)==8
write(E/'before-after.json',{'before':before,'after':after,'combinationBefore':{k:load(E/'before-combination/before-extra-results.json')[k] for k in ['passed','failed','skipped']},'combinationAfter':{x:checks[x]['combination'] for x in ['local','packed']}})
# Compare independent combination seed lists verbatim, plus old independent seeds/expectations.
assert load(E/'before-combination/before-extra-seeds.json')==load(E/'local-combination/local-extra-seeds.json')==load(P/'packed-extra-seeds.json')
working=load(P/'working-files.json');assert all(sha(R/r['file'])==r['sha256'] for r in working['files']);assert hashlib.sha256(json.dumps(working['files'],separators=(',',':')).encode()).hexdigest()==working['workingDigest'];assert sha(pathlib.Path(pv['artifact']))==pv['artifactSha256']
start=load(E/'starting-state.json');changed=[f for f,h in start['files'].items() if not (R/f).exists() or sha(R/f)!=h];allowed=['src/project-consumers.ts','bin/project-consumers.js','dev/consumer-analysis/loader-cases.mjs','dev/consumer-analysis/pack-working-candidate.mjs','docs/project-consumer-analysis.md'];assert set(changed)<=set(allowed),changed
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();branch=subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip();index=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True);assert head==start['head'] and branch=='website/docs' and not index;assert sha(pathlib.Path('/private/tmp/any-doctor-loader-repair/candidate-packed/any-doctor-0.1.2.tgz'))=='7514412f86fc93d22fda4f6de15ec95f0c8172de48f31182b6811f7b7be5c844'
write(E/'preservation.json',{'head':head,'branch':branch,'indexEmpty':not index,'startingManifestEntries':start['manifestEntries'],'startingManifestDrift':start['drift'],'changedExistingFiles':changed,'allOtherStartingFileHashesUnchanged':True,'oldTarballUnchanged':True,'frozenFiles':len(expected),'workingManifestEntries':len(working['files']),'workingDigest':working['workingDigest']})
write(E/'verification-counts.json',checks);print(json.dumps({'counts':checks,'frozen':frozen,'artifact':pv['artifact'],'sha256':pv['artifactSha256'],'workingDigest':working['workingDigest'],'changedExistingFiles':changed},indent=2))
