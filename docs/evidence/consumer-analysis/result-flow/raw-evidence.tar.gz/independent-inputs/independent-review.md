# Independent loader-classification retest

The three previously demonstrated false positives are fixed in both the rebuilt working files and the exact new tarball. The update implements shared runtime-expression normalization and explicit loader-related classification, and the original non-loader controls still pass. Acceptance of those three repairs is warranted on the tested forms.

The broader requirement to retain unrelated positive findings is not completely satisfied: one new independent conditional-loader result-flow case hides an unrelated unused export. This is a recall defect caused by overbroad uncertainty. It is distinct from the previous live-consumer false positives. The minimal reproduction and source explanation below provide a bounded follow-up; no source was repaired during this review.

Candidate: `/Users/nickdejesus/Code/any-doctor`, branch `website/docs`, HEAD `d81987b62429765b4f64fa4b8dbcbb96f10966d2` (evidence-only). The candidate remains unstaged/untracked working files. All 175 manifest entries matched before and after tests; ordered manifest SHA-256 is `e0f1619daf00939e603134a20b2779fddb784e982a0105c44e7f80f61992f528`.

The artifact `/private/tmp/any-doctor-loader-repair/candidate-packed/any-doctor-0.1.2.tgz` matched SHA-256 `7514412f86fc93d22fda4f6de15ec95f0c8172de48f31182b6811f7b7be5c844`. A fresh installation under `/private/tmp/any-doctor-loader-independent-piyjfxj8/consumer` used canonical paths. Install and `npm ls --all --json` exited zero. All 86 runtime/doctor/package files compared equal among tarball, installation and rebuilt working files. Packed verification ran from the fresh consumer; discovery selected bundled installed doctors. Labeled cases, independent scans and frozen scans used explicit installed CLI/doctor paths.

Counts are passed / failed / skipped:

| Gate | Local | Packed |
| --- | --- | --- |
| npm test including rebuild | 532 / 0 / 0 | Source suite not shipped |
| Labeled CLI cases | 145 / 0 / 0 | 145 / 0 / 0 |
| Per-export loader scope assertions | 65 / 0 / 0 | 65 / 0 / 0 |
| Original independent suite, unchanged | 29 / 1 / 0 | 29 / 1 / 0 |
| Previous repair-review suite, unchanged | 32 / 1 / 0 | 32 / 1 / 0 |
| Fresh independent combination tests | 11 / 1 / 0 | 11 / 1 / 0 |
| Bundled verification | 228 / 0 / 18 | 228 / 0 / 18 |
| Supplemental result-flow isolation | 2 / 2 / 0 | 2 / 2 / 0 |

The isolation cases investigate the same new failure; they are not additional distinct defects. The original failure remains `.mts`; the previous suite failure remains `.cts`. Their seeds and expectations were compared with the retained independent originals and are unchanged. No extension failure was weakened or converted into a skip. `.cjs` diagnostic scope remains an inherited documented limitation. The 18 bundled skips remain legacy unexercised coverage.

Every requested gate command exited zero. JSON counts were inspected directly, including independent runners that return zero despite failed assertions. The new independent combination runner deliberately exited 1 for its one failed assertion in each environment. `local-commands.json`, `packed-commands.json`, and logs record executions. The original suites' intentional parse-error child failures remain expected passing assertions.

The new combination tests exercise nested assertions/non-null/satisfies wrappers across factory, computed property, base, initializer, callee and target; default/named/namespace imports; multiple factory and loader aliases; shared loader use across targets; wrapped ordinary functions; lexical module shadowing; require.resolve through a computed alias; unrelated unknown calls; uncertain factory selection; and unsupported bases. All ten executable runtime witnesses in each 12-case set exited zero. The combined-wrapper and alias consumers preserve only their target modules and leave the unrelated unused export visible.

**Remaining defect: module results inherit conditional-loader provenance.**

Seed files:

```ts
// src/target.ts
export function helper(){return 42;}

// other/dead.ts
export const dead=13;

// src/index.ts
import {createRequire} from "node:module";
const r=createRequire(import.meta.url);
const load=Date.now()>0 ? r : ((v:string)=>v);
console.log((load("./target.ts") as any).helper());
```

Node prints `42` and exits zero. The correct export finding is `other/dead.ts:dead`. Both candidates emit zero export findings and record conditional-loader uncertainty against both target.ts and dead.ts.

The isolation establishes the trigger:

| Form | Actual uncertainty | Unrelated dead export reported? |
| --- | --- | --- |
| Conditional `load("./target.ts")`, print returned value | target.ts only | Yes |
| Conditional `load("./target.ts").helper()` | target.ts and dead.ts | No |
| Store conditional load result, then `mod.helper()` | target.ts and dead.ts | No |
| Known `r("./target.ts").helper()` | target.ts only | Yes |

All eight local/packed isolation runtime runs exited zero. The module method calls print 42. Per-export host evidence, not just headline issue counts, proves the unrelated export was suppressed.

Source cause is in `/Users/nickdejesus/Code/any-doctor/src/project-consumers.ts`, the `classifyUncached` CallExpression branch around lines 750–759. A conditional loader is correctly represented as `unsupported` with a known importer base. But `if (callee.kind === "unsupported") return callee` copies that callable classification onto the loaded module result. Member access preserves it again. The later `.helper()` call is then treated as another loader invocation with no literal module argument, which applies project-wide uncertainty. The nearby rule preventing known loader results from automatically becoming loaders only handles `callee.kind === "loader"`.

Bounded follow-up: preserve the possible semantic role when loader analysis is unsupported. Uncertainty about selecting a loader must not automatically imply that the result of calling it is itself a loader. Distinguish unsupported factory selection (which may produce a loader) from unsupported loader selection (which loads a module). Record the original call's target uncertainty without transferring loader-callable provenance to arbitrary methods of its result. Do not fix this by globally ignoring unsupported calls, which would restore the earlier safety problem. Regress direct and stored result-member calls alongside the existing direct-call control, and assert the exact unaffected export and per-export uncertainty scopes.

Executable new cases are retained in `extra-challenges.py` and per-label `*-extra-seeds.json`. The focused reproduction is retained in `isolate-result-flow.py` and `result-flow-isolation.json`. To reproduce the minimal scan without modifying the candidate:

```sh
node /Users/nickdejesus/Code/any-doctor/bin/cli.js run /Users/nickdejesus/Code/any-doctor/doctors/slop.mjs /private/tmp/any-doctor-loader-independent-piyjfxj8/isolation/local/conditional-member --format json
node /private/tmp/any-doctor-loader-independent-piyjfxj8/isolation/local/conditional-member/src/index.ts
```

**Frozen result and preservation.** Both Sift scans remain 671 diagnostic files, 67 findings and 20 coverage issues. Finding arrays, messages, decision keys and coverage content match retained `sift-after.json`; only measured analysis duration differs. No changed Sift finding required new source adjudication. The prior 19 export suppressions based solely on type evidence remain a conservative policy tradeoff, not evidence of production callers. Constant traversal/config uncertainty can still hide genuine unused exports.

All 1,530 frozen files matched hashes and sizes before and after the run, with no extras. Live Sift was not scanned or modified. All 434 recorded tracked/untracked working files retained their initial hashes. No reset, checkout, staging, commit, push, publication or source repair occurred. Original evidence was read-only; all new evidence is under `/private/tmp/any-doctor-loader-independent-piyjfxj8`.

Evidence index: `summary.json` contains results and preservation checks; `integrity-before.json` and `candidate-manifest.json` bind provenance; `packed-comparison.json` binds installed files; `npm-test.log`, the local/packed gate logs and result JSONs retain counts; `local-extra-results.json`, `packed-extra-results.json`, and `result-flow-isolation.json` contain the new counterexample and runtime proof. `candidate-project-consumers.ts` preserves the exact reviewed implementation. `run-gates.py`, `extra-challenges.py`, and `isolate-result-flow.py` retain executable commands; use fresh labels/directories when rerunning.

Verdict: accept the three previously failed loader forms and the normalization/binding improvements. Keep one focused follow-up open for conditional-loader result-flow uncertainty before claiming the entire requested unrelated-positive contract is met. The bounded tests do not establish universal precision or deletion safety.
