import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
return (args.flag?ctx.db.query('rows').withIndex('by_x',q=>opaque(q)):ctx.db.query('rows').withIndex('by_x',q=>q.eq('x',1))).filter(q=>q.eq(q.field('x'),1)).collect();
}});
