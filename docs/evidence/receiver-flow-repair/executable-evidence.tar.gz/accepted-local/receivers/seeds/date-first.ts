import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
const clock=args.flag?Date.now:performance.now;return clock();
}});
