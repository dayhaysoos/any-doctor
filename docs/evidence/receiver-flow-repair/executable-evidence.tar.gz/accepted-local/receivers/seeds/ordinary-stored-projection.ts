import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
const object={rows:external,other:ctx.db.query('rows').withIndex('by_x').filter(q=>q.eq(q.field('x'),1))};return object.rows.collect();
}});
