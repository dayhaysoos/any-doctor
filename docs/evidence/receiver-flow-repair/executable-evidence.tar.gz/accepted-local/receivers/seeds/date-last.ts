import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
const clock=args.flag?performance.now:Date.now;return clock();
}});
