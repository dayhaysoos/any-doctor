import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
const box={rows:external};const alias=box;alias.rows=ctx.db.query('rows').withIndex('by_x').filter(q=>q.eq(q.field('x'),1));await box.rows.collect();
await ctx.db.query('neighbors').collect();
}});
