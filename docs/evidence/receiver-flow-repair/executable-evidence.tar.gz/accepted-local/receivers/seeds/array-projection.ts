import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
await [ctx.db.query('rows').withIndex('by_x').filter(q=>q.eq(q.field('x'),1))][0].collect();
await ctx.db.query('neighbors').collect();
}});
