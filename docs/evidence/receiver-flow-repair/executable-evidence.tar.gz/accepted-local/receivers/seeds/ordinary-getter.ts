import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
return ({get rows(){return external;}}).rows.collect();
}});
