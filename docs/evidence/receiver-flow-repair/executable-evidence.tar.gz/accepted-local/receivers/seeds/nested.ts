import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
await (args.flag?external:(args.other?ctx.db.query('rows').withIndex('by_x').filter(q=>q.eq(q.field('x'),1)):external)).collect();
await ctx.db.query('neighbors').collect();
}});
