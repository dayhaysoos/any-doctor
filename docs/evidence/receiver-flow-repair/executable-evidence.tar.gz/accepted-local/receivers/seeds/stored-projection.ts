import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
const object={rows:ctx.db.query('rows').withIndex('by_x').filter(q=>q.eq(q.field('x'),1))};await object.rows.collect();
await ctx.db.query('neighbors').collect();
}});
