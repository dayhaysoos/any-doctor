import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
let rows=external;await (rows??=ctx.db.query('rows').withIndex('by_x').filter(q=>q.eq(q.field('x'),1))).collect();
await ctx.db.query('neighbors').collect();
}});
