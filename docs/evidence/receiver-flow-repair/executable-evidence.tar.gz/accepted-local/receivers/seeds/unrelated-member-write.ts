import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
const box={rows:external};box.other=ctx.db.query('rows').withIndex('by_x').filter(q=>q.eq(q.field('x'),1));return box.rows.collect();
}});
