import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
return wrap(external).collect();
}});
