import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
return (args.flag?ctx.db.query('rows').filter(q=>q.eq(q.field('x'),1)):ctx.db.query('rows').withIndex('by_x')).collect();
}});
