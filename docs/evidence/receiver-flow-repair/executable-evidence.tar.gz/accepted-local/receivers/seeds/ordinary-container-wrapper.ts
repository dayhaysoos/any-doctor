import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
return wrap({rows:external}).collect();
}});
