import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
let rows=ctx.db.query('rows').withIndex('by_x').filter(q=>q.eq(q.field('x'),1));const alias=rows;rows=alias;await rows.collect();
await ctx.db.query('neighbors').collect();
}});
