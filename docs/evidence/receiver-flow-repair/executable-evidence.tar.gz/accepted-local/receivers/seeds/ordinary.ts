import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
const rows={collect(){return [];}};return rows.collect();
}});
