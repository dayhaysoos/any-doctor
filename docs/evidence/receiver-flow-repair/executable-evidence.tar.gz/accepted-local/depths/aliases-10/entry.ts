import {query} from './_generated/server';
query({args:{},handler:async(ctx,args)=>{
const a0=ctx.db.query('rows').withIndex('by_x').filter(q=>q.eq(q.field('x'),1));
const a1=args.flag?a0:a0;
const a2=args.flag?a1:a1;
const a3=args.flag?a2:a2;
const a4=args.flag?a3:a3;
const a5=args.flag?a4:a4;
const a6=args.flag?a5:a5;
const a7=args.flag?a6:a6;
const a8=args.flag?a7:a7;
const a9=args.flag?a8:a8;
const a10=args.flag?a9:a9;
return a10.collect();
}});
