getItems().map(async value=>value);
[1].map(async value=>value);