const invoke=fetch;
invoke("/");