import pathlib,subprocess,json,hashlib,time,os,re,sys
R=pathlib.Path('<repo>');O=pathlib.Path(__file__).parent;F=pathlib.Path('<frozen-target>');label=sys.argv[1];C=pathlib.Path(sys.argv[2]) if len(sys.argv)>2 else R

def write(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n')
def run(n,args,cwd=C,env=None):
 t=time.monotonic();p=subprocess.run([str(x) for x in args],cwd=cwd,capture_output=True,text=True,env=env);(O/(n+'.stdout')).write_text(p.stdout);(O/(n+'.stderr')).write_text(p.stderr);write(n+'.command.json',dict(command=[str(x) for x in args],cwd=str(cwd),exit=p.returncode,wallMs=round(1000*(time.monotonic()-t))));assert p.returncode==0,(n,p.stderr[-500:]);return p

def manifest(n):
 m=json.loads((R/'docs/evidence/consumer-analysis/sift-manifest.json').read_text());changed=[x['file'] for x in m['files'] if hashlib.sha256((F/x['file']).read_bytes()).hexdigest()!=x['sha256']];write(n,dict(expected=len(m['files']),matched=len(m['files'])-len(changed),changed=changed));assert not changed
manifest(label+'-manifest-before.json');cli=C/'bin/cli.js';doctor=C/'doctors/async.mjs';s={}
p=run(label+'-verify-all',['node',cli,'verify','--all']);s['bundled']={k:len(re.findall(pattern,p.stdout)) for k,pattern in [('passed',r'  ✔ '),('failed',r'  ✘ '),('skipped',r'  – ')]};assert s['bundled']==dict(passed=265,failed=0,skipped=15)
for mode in ['json','human']:
 p=run(label+'-profiles-'+mode,['node',cli,'verify',doctor,*(['--format','json'] if mode=='json' else [])]);
 if mode=='json':
  profiles=[x for x in json.loads(p.stdout)['results'] if x['name'].startswith('challenge profile:')];s['profiles']=dict(passed=sum(x['ok'] and not x.get('skipped') for x in profiles),failed=sum(not x['ok'] for x in profiles),skipped=sum(bool(x.get('skipped')) for x in profiles));assert s['profiles']==dict(passed=21,failed=0,skipped=0)
p=run(label+'-focused',['node','--test',R/'test/sdk-candidate-boundaries.test.mjs',R/'test/sdk-invariants.test.mjs'],env={**os.environ,'DOCTOR_CANDIDATE_ROOT':str(C)})
s['focused']={k:int(re.search(r'ℹ '+term+r' (\d+)',p.stdout)[1]) for k,term in [('passed','pass'),('failed','fail'),('skipped','skipped')]};assert s['focused']['failed']==0
run(label+'-mutations',['node',R/'dev/doctor-sdk/run-profile-mutations.mjs',O/(label+'-mutations')]);
p=run(label+'-sift',['node',cli,'run',doctor,F,'--format','json']);j=json.loads(p.stdout);s['frozen']=dict(files=j['fileCount'],findings=j['counts']['total'],coverage=[{k:x[k] for k in ['check','reason','occurrences']} for x in j['groups'][0]['semantic']['narrowed']]);
old=json.loads((R/'docs/evidence/doctor-sdk-foundations/765c29a-calibration/local/local-sift-0.stdout').read_text());assert old['groups'][0]['checks']==j['groups'][0]['checks']
write(label+'-projection.json',dict(checks=j['groups'][0]['checks'],narrowed=j['groups'][0]['semantic']['narrowed']));manifest(label+'-manifest-after.json');write(label+'-summary.json',s);print(json.dumps(s,indent=2))
