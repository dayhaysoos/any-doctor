import pathlib,subprocess,json,hashlib,tarfile,re,os,time
R=pathlib.Path('<REPO>');O=pathlib.Path(__file__).parent

def run(name,args,cwd=R,env=None):
 t=time.monotonic();p=subprocess.run(list(map(str,args)),cwd=cwd,capture_output=True,text=True,env={**os.environ,**(env or {})});(O/(name+'.stdout')).write_text(p.stdout);(O/(name+'.stderr')).write_text(p.stderr);(O/(name+'.command.json')).write_text(json.dumps(dict(command=list(map(str,args)),cwd=str(cwd),env=env or {},exit=p.returncode,wallMs=round(1000*(time.monotonic()-t))),indent=2));assert p.returncode==0,(name,p.stderr[-500:],p.stdout[-600:]);return p

def counts(text):return {k:int(re.search(r'ℹ '+term+r' (\d+)',text)[1]) for k,term in [('passed','pass'),('failed','fail'),('skipped','skipped')]}
def gates(label,candidate):
 s={};p=run(label+'-verify-all',['node',candidate/'bin/cli.js','verify','--all'],cwd=candidate);s['bundled']={k:len(re.findall(pattern,p.stdout)) for k,pattern in [('passed',r'  ✔ '),('failed',r'  ✘ '),('skipped',r'  – ')]};assert s['bundled']==dict(passed=265,failed=0,skipped=15)
 for name,files in [('focused',['dashboard','sdk-invariants','sdk-candidate-boundaries']),('unicode',['tty-unicode'])]:
  p=run(label+'-'+name,['node','--test',*[R/f'test/{f}.test.mjs' for f in files]],env={'DOCTOR_CANDIDATE_ROOT':str(candidate),'DASHBOARD_WIDTH_EVIDENCE':str(O/(label+'-measurements.json'))} if name=='focused' else {'DOCTOR_CANDIDATE_ROOT':str(candidate)});s[name]=counts(p.stdout);assert not s[name]['failed']
 p=run(label+'-semantic-mutations',['node',R/'dev/doctor-sdk/run-semantic-mutations.mjs',candidate,O/(label+'-mutations')]);s['mutations']={k:json.loads(p.stdout)[k] for k in ['passed','failed','skipped']};assert s['mutations']==dict(passed=7,failed=0,skipped=0)
 (O/(label+'-summary.json')).write_text(json.dumps(s,indent=2));print(label,s,flush=True);return s
if os.environ.get('VERIFY_PHASE')=='full':
 p=run('npm-test',['npm','test']);(O/'full-summary.json').write_text(json.dumps(counts(p.stdout),indent=2));print(counts(p.stdout));raise SystemExit
local=gates('local',R)
P=O/'package';P.mkdir();p=run('pack',['npm','pack','--ignore-scripts','--pack-destination',P,'--json']);pack=json.loads(p.stdout)[0];a=P/pack['filename']
with tarfile.open(a) as t:
 for m in t.getmembers():
  if m.isfile():assert t.extractfile(m).read()==(R/pathlib.PurePosixPath(m.name).relative_to('package')).read_bytes(),m.name
artifact=dict(path=str(a),bytes=a.stat().st_size,files=len(pack['files']),sha256=hashlib.sha256(a.read_bytes()).hexdigest());(O/'artifact.json').write_text(json.dumps(artifact,indent=2))
C=O/'consumer';C.mkdir();(C/'package.json').write_text('{"private":true}');run('install',['npm','install','--ignore-scripts','--no-audit','--no-fund',a],cwd=C);installed=C/'node_modules/any-doctor'
packed=gates('packed',installed)
run('optional',['node',R/'dev/doctor-sdk/check-optional-provider.mjs',a,O/'optional-consumer'])
p=run('optional-dashboard-unicode',['node','--test',R/'test/dashboard.test.mjs',R/'test/tty-unicode.test.mjs'],env={'DOCTOR_CANDIDATE_ROOT':str(O/'optional-consumer/node_modules/any-doctor'),'DASHBOARD_WIDTH_EVIDENCE':str(O/'optional-measurements.json')});(O/'optional-tests-summary.json').write_text(json.dumps(counts(p.stdout),indent=2));assert not counts(p.stdout)['failed']
# The production dependency is present, identical and pinned in each consumer.
dep='get-east-asian-width'
for label,root in [('local',R),('packed',C),('optional',O/'optional-consumer')]:
 pkg=json.loads((root/f'node_modules/{dep}/package.json').read_text());assert pkg['version']=='1.6.0';assert pkg['license']=='MIT'
 files={str(p.relative_to(root/f'node_modules/{dep}')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/f'node_modules/{dep}').rglob('*') if p.is_file()};(O/(label+'-dependency-files.json')).write_text(json.dumps(files,indent=2))
arrays=[json.loads((O/(label+'-measurements.json')).read_text()) for label in ['local','packed','optional']];assert arrays[0]==arrays[1]==arrays[2]
for m in arrays[0]:assert m['logicalLines']==m['physicalRows']==m['rows']-1 and m['maximumVisibleWidth']<=m['cols'],m
print(json.dumps(dict(local=local,packed=packed,artifact=artifact,measuredFrames=len(arrays[0]),parity=True),indent=2))
