import { test, after } from "node:test";
import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import * as fs from "fs";
import * as os from "os";
import * as path from "path";
import { fileURLToPath } from "node:url";

const candidate=process.env.DOCTOR_CANDIDATE_ROOT ?? fileURLToPath(new URL("../", import.meta.url));

// The clipboard is injected via deps in runDashboardOn tests, keeping them
// deterministic and spawn-free.
const { buildListRows, scoreBar, runDashboardOn, dashboardFrame } = await import(`${candidate}/bin/dashboard.js`);
const { buildTree } = await import(`${candidate}/bin/doctor-tree.js`);
const { reviewOf } = await import(`${candidate}/bin/review.js`);
const { encodeDecisionKey } = await import(`${candidate}/bin/finding-state.js`);
const { captureScan } = await import(`${candidate}/bin/scan-capture.js`);
const deriveSummaryOf = (await import(`${candidate}/bin/summary.js`)).deriveSummary;
import { terminalCells, plainSgr } from "./support/terminal-cells.mjs";
const widthMeasurements = [];
// TTY paint controls move/clear the cursor; preserve SGR color for the independent cell oracle.
const unpaint = frame => frame.replace(/\x1b\[(?:\?2026[hl]|H|K|J)/g, '');
const physicalRows = (lines, cols) => lines.reduce((total, line) => total + Math.max(1, Math.ceil(terminalCells(line) / cols)), 0);
function assertFrameFits(frame, {cols, rows, label, useColor}) {
  const lines = unpaint(frame).split('\n');
  const widths = lines.map(terminalCells);
  const measurement = {label, cols, rows, useColor, logicalLines: lines.length,
    maximumVisibleWidth: Math.max(...widths), physicalRows: physicalRows(lines, cols)};
  widthMeasurements.push(measurement);
  assert.equal(measurement.logicalLines, rows - 1, `${label}: logical frame height`);
  assert.ok(widths.every(width => width <= cols), `${label}: visible width ${measurement.maximumVisibleWidth} exceeds ${cols}; physical rows ${measurement.physicalRows}, expected ${rows - 1}`);
  assert.equal(measurement.physicalRows, rows - 1, `${label}: physical frame height`);
  return measurement;
}
after(() => {
  if (process.env.DASHBOARD_WIDTH_EVIDENCE) fs.writeFileSync(process.env.DASHBOARD_WIDTH_EVIDENCE, JSON.stringify(widthMeasurements, null, 2)+'\n');
});
const { doctorDigests } = await import(`${candidate}/bin/identity.js`);
const provOf = (doctorId, programText) => ({ revisions: new Map(), programDigests: new Map([[doctorId, doctorDigests([{ id: doctorId, programPath: "/fixture" }], () => programText)[0].digest]]) });


const { deriveSummary } = await import(`${candidate}/bin/summary.js`);
// The tree consumes the Summary's check buckets; tests build them the way
// production does — through the one derivation.
const gcOf = (groups) => deriveSummary({ groups, crashed: [], skippedUnsafe: [], doctorPaths: new Map(), fileCount: 0, durationMs: 0, targetDir: "." }).groupChecks;
const copyAlways = { copy: () => true };

const groups = [
  {
    programName: "stripe-doctor.mjs",
    meta: {
      id: "stripe-doctor",
      description: "Deprecated Stripe usage",
      severity: "warning",
      category: "bugs",
      checks: [
        { id: "charges-create", description: "Direct legacy charge creation", severity: "error", impact: "money moves wrong", why: "charges.create is legacy", fix: "use paymentIntents" },
      ],
      blindSpots: ["aliased clients"],
    },
    findings: [
      { rule: "charges-create", file: "src/a.ts", line: 2 },
      { rule: "charges-create", file: "src/a.ts", line: 9 },
    ],
  },
  {
    programName: "other.mjs",
    meta: { id: "other", description: "Other checks", severity: "info" },
    findings: [{ file: "src/b.ts", line: 7 }],
  },
];

test("buildListRows: multi-doctor frames render collapsible doctor rows", async () => {
  const { initialExpanded } = await import(`${candidate}/bin/doctor-tree.js`);
  const gc = gcOf(groups);
  const expanded = initialExpanded(buildTree(gc, 10));
  assert.ok(expanded.has("stripe-doctor"), "the error-carrying top doctor opens on entry");
  assert.ok(!expanded.has("other"), "the info-only doctor starts collapsed");
  const rows = buildListRows(buildTree(gc, 10), false, 0, new Set(), expanded);
  assert.deepEqual(rows.map(r => r.kind), ["section", "item", "item", "section"]);
  assert.match(rows[0].text, /stripe-doctor ×2/);
  assert.ok(rows[0].selectable, "doctor rows are the selection surface");
  assert.match(rows[3].text, /other ×1/);
  assert.ok(rows[3].text.includes("\u25b8"), "other collapsed");
  const opened = buildListRows(buildTree(gc, 10), false, 0, new Set(), new Set([...expanded, "other"]));
  assert.ok(opened.some(r => r.text.includes("src/b.ts:7")), "expanding a doctor reveals its findings");
});

test("scoreBar: fills proportionally", () => {
  assert.equal(scoreBar(100, 10), "██████████");
  assert.equal(scoreBar(0, 10), "░░░░░░░░░░");
  assert.equal(scoreBar(50, 10), "█████░░░░░");
});

class FakeStdin extends EventEmitter {
  isTTY = true;
  isRaw = false;
  rawModeHistory = [];
  resumed = 0;
  paused = 0;
  listenersAttached = 0;
  setRawMode(mode) {
    this.isRaw = mode;
    this.rawModeHistory.push(mode);
  }
  resume() { this.resumed++; }
  pause() { this.paused++; }
  on(event, listener) {
    if (event === "data") this.listenersAttached++;
    return super.on(event, listener);
  }
  send(s) { this.emit("data", Buffer.from(s, "utf8")); }
}

class FakeStdout {
  isTTY = true;
  columns = 120;
  rows = 34;
  frames = [];
  write(s) { this.frames.push(s); }
}

function dashInput(groupsOverride = groups) {
  return {
    outcome: {
      groups: groupsOverride,
      crashed: [],
      skippedUnsafe: [],
      doctorPaths: new Map(),
      fileCount: 2,
      durationMs: 10,
      targetDir: ".",
    },
    useColor: false,
  };
}

function settle(promise) {
  return Promise.race([
    promise.then(() => "resolved", (e) => "rejected: " + e),
    new Promise((r) => setTimeout(() => r("still pending"), 1000)),
  ]);
}

test("runDashboard: revives a post-picker stdin (paused, cooked) and stays interactive until q", async () => {
  const stdin = new FakeStdin(); // models stdin exactly as pickItem's cleanup leaves it
  const stdout = new FakeStdout();
  const done = runDashboardOn({ stdin, stdout }, dashInput(), copyAlways);

  assert.equal(stdin.rawModeHistory[0], true, "must enter raw mode before reading keys (cooked mode line-buffers arrows and echoes)");
  assert.ok(stdin.resumed >= 1, "must resume stdin — the picker pauses it, and an explicitly paused stdin never auto-flows, so the loop drains and the process exits 0");
  assert.match(stdout.frames[stdout.frames.length - 1], /a accept/);

  stdin.send("\x1b[B");
  stdin.send("\x1b[B");
  const afterDown = stdout.frames[stdout.frames.length - 1];
  assert.match(afterDown, /›✖ src\/a\.ts:9/, "down arrows walk from the doctor row onto its second instance");

  stdin.send("\r");
  const afterEnter = stdout.frames[stdout.frames.length - 1];
  assert.match(afterEnter, /copied finding/, "enter copies the finding and keeps the dashboard open");
  assert.doesNotMatch(afterEnter, /DASHBOARD RENDER ERROR/);

  stdin.send("q");
  assert.equal(await settle(done), "resolved", "q must resolve the dashboard loop (finish wiring)");
  assert.equal(stdin.rawModeHistory[stdin.rawModeHistory.length - 1], false, "restores previous raw mode on exit");
  assert.ok(stdin.paused >= 1, "pauses stdin on exit");
  assert.ok(stdout.frames[stdout.frames.length - 1].includes("\x1b[?25h"), "shows the cursor again on exit");
});

test("runDashboard: ctrl-c exits the loop like q", async () => {
  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const done = runDashboardOn({ stdin, stdout }, dashInput(), copyAlways);
  stdin.send("\x03");
  assert.equal(await settle(done), "resolved");
});

test("runDashboard: enter on an empty findings list draws instead of crashing", async () => {
  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const done = runDashboardOn({ stdin, stdout }, dashInput([{ ...groups[0], findings: [] }]), copyAlways);
  stdin.send("\r");
  assert.doesNotMatch(stdout.frames[stdout.frames.length - 1], /DASHBOARD RENDER ERROR/);
  stdin.send("q");
  assert.equal(await settle(done), "resolved");
});

test("dashboardFrame: unsafe skips appear as one header note line", () => {
  const gc = gcOf(groups);
  const frame = dashboardFrame({
    tree: buildTree(gc, 10),
    selectedRow: 0,
    readKeys: new Set(),
    readSource: () => null,
    filesTotal: 2,
    durationMs: 10,
    useColor: false,
    skippedUnsafe: ["evil"],
    cols: 120,
    rows: 34,
  });
  assert.match(frame, /⚠ 1 doctor could be malicious — skipped: evil/);
});

test("dashboardFrame: frame height is exactly rows - 1 in every state (notice never resizes it)", () => {
  const gc = gcOf(groups);
  const height = (notice, cols, selected) => assertFrameFits(
    dashboardFrame({ tree: buildTree(gc, 10), selectedRow: selected, readKeys: new Set(), readSource: () => null, filesTotal: 2, durationMs: 10, useColor: false, notice, cols, rows: 34 }),
    {cols, rows:34, useColor:false, label:'notice frame'}).logicalLines;
  assert.equal(height(undefined, 120, 0), 33, "split, no notice");
  assert.equal(height("copied finding — paste into your agent", 120, 0), 33, "split, with notice");
  assert.equal(height(undefined, 120, 2), 33, "split, last item selected");
  assert.equal(height(undefined, 80, 0), 33, "stacked, no notice");
  assert.equal(height("copied", 80, 0), 33, "stacked, with notice");
});

test("runDashboard: repaints in place — no full-screen erase after the first paint", async () => {
  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const done = runDashboardOn({ stdin, stdout }, dashInput(), copyAlways);

  const paints = stdout.frames.filter(f => f.includes("\x1b[H"));
  assert.ok(paints.length >= 1, "at least one paint happened");
  const first = paints[0];
  assert.ok(first.startsWith("\x1b[?2026h\x1b[H"), "first paint is in-place too — the picker's leftovers are overwritten, not blanked");

  stdin.send("\x1b[B");
  stdin.send("\r");
  const later = stdout.frames[stdout.frames.length - 1];
  assert.ok(later.startsWith("\x1b[?2026h\x1b[H"), "later paints home the cursor, synchronized");
  assert.ok(!later.includes("\x1b[2J"), "later paints never blank the whole screen");
  assert.ok(later.includes("\x1b[K"), "each rewritten line clears to end-of-line");
  assert.ok(later.endsWith("\x1b[J\x1b[?2026l"), "paint clears below the frame and closes the synchronized window");

  stdin.send("q");
  assert.equal(await settle(done), "resolved");
});

test("dashboardFrame: pure state -> string; code frames come from the injected source", async () => {
  const gc = gcOf(groups);
  const source = ["one", "two", "const three = 3", "four", "five"];
  const readSource = (file) => (file === "src/a.ts" ? source : null);
  const state = { tree: buildTree(gc, 10), selectedRow: 1, readKeys: new Set(), readSource, expanded: new Set(["stripe-doctor"]), filesTotal: 2, durationMs: 10, useColor: false, cols: 120, rows: 34 };

  const once = dashboardFrame(state);
  assert.equal(dashboardFrame(state), once, "same state, same frame — no hidden I/O");
  assert.match(once, /> +2 │ two/, "code frame renders the injected source with the marker line");
  const bare = dashboardFrame({ ...state, readSource: () => null });
  assert.match(bare, /\(source unavailable\)/, "a file with no source renders the fallback");
});

test("dashboardFrame with color: header carries no function source", () => {
  const gc = gcOf(groups);
  const out = dashboardFrame({ tree: buildTree(gc, 10), selectedRow: 0, readKeys: new Set(), readSource: () => null, filesTotal: 2, durationMs: 10, useColor: true, cols: 120, rows: 34 });
  assert.ok(!out.includes("function gradeColor"), "gradeColor is called, not concatenated");
});

// ---- the check tree: multi-check doctors ----

const multiGroups = [{
  programName: "multi.mjs",
  meta: {
    id: "multi-doctor",
    description: "Multi-check doctor",
    severity: "warning",
    checks: [
      { id: "bad-error", description: "Error check", severity: "error", why: "because", impact: "bad", fix: "fix it" },
      { id: "meh-warn", description: "Warning check", severity: "warning" },
    ],
  },
  findings: [
    { rule: "bad-error", file: "a.ts", line: 1 },
    { rule: "bad-error", file: "a.ts", line: 2 },
    { rule: "meh-warn", file: "b.ts", line: 3 },
  ],
}];

test("tree: checks render as severity-ordered rows; errors start expanded, warnings collapsed", async () => {
  const { buildListRows } = await import(`${candidate}/bin/dashboard.js`);
  const { initialExpanded } = await import(`${candidate}/bin/doctor-tree.js`);
  const gc = gcOf(multiGroups);
  const expanded = initialExpanded(buildTree(gc, 10));
  assert.deepEqual([...expanded], ["multi-doctor/bad-error"], "only the error check opens on entry");
  const rows = buildListRows(buildTree(gc, 10), false, 0, new Set(), expanded);
  assert.deepEqual(rows.map(r => r.kind), ["section", "check", "item", "item", "check"]);
  assert.match(rows[1].text, /Error check/, "error check first (severity ordering)");
  assert.match(rows[1].text, /×2/);
  assert.ok(rows[1].text.includes("\u25be"), "error check expanded");
  assert.match(rows[4].text, /Warning check ×1/);
  assert.ok(rows[4].text.includes("\u25b8"), "warning check collapsed");
  assert.ok(!rows.some(r => r.text.includes("b.ts")), "warning instances hidden until expanded");
});

test("tree: expanding a warning check reveals its instances in the frame", async () => {
  const { dashboardFrame } = await import(`${candidate}/bin/dashboard.js`);
  const { initialExpanded } = await import(`${candidate}/bin/doctor-tree.js`);
  const gc = gcOf(multiGroups);
  const base = { tree: buildTree(gc, 10), selectedRow: 1, readKeys: new Set(), readSource: () => null, filesTotal: 1, durationMs: 5, useColor: false, cols: 120, rows: 34 };
  const closed = dashboardFrame({ ...base, expanded: initialExpanded(buildTree(gc, 10)) });
  assert.ok(closed.includes("a.ts:1") && !closed.includes("b.ts:3"));
  const open = dashboardFrame({ ...base, expanded: new Set(["multi-doctor/bad-error", "multi-doctor/meh-warn"]) });
  assert.ok(open.includes("b.ts:3"));
});

test("tree: a check row's detail pane tells the check's story", async () => {
  const { dashboardFrame } = await import(`${candidate}/bin/dashboard.js`);
  const { initialExpanded } = await import(`${candidate}/bin/doctor-tree.js`);
  const gc = gcOf(multiGroups);
  const out = dashboardFrame({ tree: buildTree(gc, 10), selectedRow: 1, readKeys: new Set(), readSource: () => null, expanded: initialExpanded(buildTree(gc, 10)), filesTotal: 1, durationMs: 5, useColor: false, cols: 120, rows: 34 });
  assert.ok(out.includes("multi-doctor/bad-error"), "checkKey in the detail pane");
  assert.ok(out.includes("2 findings across 1 file"), "blast radius");
  assert.ok(out.includes("because"), "why text");
});

test("tree: 60 findings in one check show 50 instances plus the re-scan affordance", async () => {
  const { buildListRows } = await import(`${candidate}/bin/dashboard.js`);
  const { initialExpanded, FINDINGS_PER_CHECK } = await import(`${candidate}/bin/doctor-tree.js`);
  assert.equal(FINDINGS_PER_CHECK, 50);
  const findings = Array.from({ length: 60 }, (_, i) => ({ rule: "bad-error", file: "a.ts", line: i + 1 }));
  const gc = gcOf([{ ...multiGroups[0], findings: [...findings, { rule: "meh-warn", file: "b.ts", line: 3 }] }]);
  const rows = buildListRows(buildTree(gc, 10), false, 0, new Set(), initialExpanded(buildTree(gc, 10)));
  const kinds = rows.map(r => r.kind);
  assert.equal(kinds.filter(k => k === "item").length, 50, "instances capped");
  const more = rows.find(r => r.kind === "more");
  assert.ok(more && more.text.includes("10 more"), "the more-row counts the rest");
  assert.ok(more.text.includes("re-scan"), "the affordance names the loop");
});

test("tree: single-doctor frames stay exactly flat — headers, no tree", async () => {
  const { buildListRows } = await import(`${candidate}/bin/dashboard.js`);
  const { initialExpanded } = await import(`${candidate}/bin/doctor-tree.js`);
  const gc = gcOf([groups[0]]);
  assert.deepEqual([...initialExpanded(buildTree(gc, 10))], [], "nothing to expand in a single-doctor frame");
  const rows = buildListRows(buildTree(gc, 10), false, 0, new Set(), initialExpanded(buildTree(gc, 10)));
  assert.deepEqual(rows.map(r => r.kind), ["section", "item", "item"]);
  assert.ok(!rows[0].selectable, "the header is not a toggle in single-doctor frames");
  assert.ok(!rows.some(r => r.kind === "check" || r.kind === "more"), "no tree for one check");
});

test("tree: enter toggles checks, arrows expand and collapse, enter on an instance copies", async () => {
  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const multiInput = { ...dashInput(multiGroups) };
  const done = runDashboardOn({ stdin, stdout }, multiInput, copyAlways);

  // Initial selection is the (expanded) error check row.
  let frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.ok(frame.includes("a.ts:1"), "error check open at entry");

  stdin.send("\r"); // collapse the error check
  frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.ok(!frame.includes("a.ts:1"), "enter collapsed it");

  stdin.send("j");   // onto the warning check row
  stdin.send("\x1b[C"); // right expands
  frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.ok(frame.includes("b.ts:3"), "right arrow expanded the warning check");

  stdin.send("j");   // onto the instance row
  stdin.send("\r"); // copies
  frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.ok(frame.includes("copied finding"), "enter on an instance copies its context");

  stdin.send("q");
  const out = await settle(done);
  assert.equal(out, "resolved");
});

// ---- the aggregate experience: no-arg run, every doctor in one tree ----

const aggregateGroups = [
  { ...multiGroups[0] },
  { programName: "solo.mjs", meta: { id: "solo-doctor", description: "Solo doctor", severity: "warning" }, findings: [{ file: "c.ts", line: 1 }] },
];

test("aggregate: doctors sort worst-severity-first and the top doctor opens", async () => {
  const { buildListRows } = await import(`${candidate}/bin/dashboard.js`);
  const { initialExpanded } = await import(`${candidate}/bin/doctor-tree.js`);
  const gc = gcOf(aggregateGroups);
  const expanded = initialExpanded(buildTree(gc, 10));
  assert.ok(expanded.has("multi-doctor"), "the error-carrying doctor is expanded");
  const rows = buildListRows(buildTree(gc, 10), false, 0, new Set(), expanded);
  assert.match(rows[0].text, /multi-doctor ×3/);
  assert.ok(rows[0].text.includes("\u25be"), "top doctor open");
  const soloRow = rows.find(r => r.text.includes("solo-doctor"));
  assert.ok(soloRow && soloRow.text.includes("\u25b8"), "solo doctor collapsed");
});

test("aggregate: enter on a doctor row toggles it and the doctor detail pane renders", async () => {
  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const done = runDashboardOn({ stdin, stdout }, { ...dashInput(aggregateGroups) }, copyAlways);
  let frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.ok(frame.includes("multi-doctor"), "aggregate frame up");

  stdin.send("\r"); // initial selection is the multi-doctor row: collapse it
  frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.ok(!frame.includes("a.ts:1"), "doctor collapsed");
  assert.ok(frame.includes("3 findings"), "doctor detail pane shows the rollup");

  stdin.send("\r"); // expand again
  frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.ok(frame.includes("a.ts:1"), "doctor re-expanded");

  stdin.send("q");
  assert.equal(await settle(done), "resolved");
});

test("tree: children hang off connectors; guides hold the column under an expanded check", async () => {
  const { buildListRows } = await import(`${candidate}/bin/dashboard.js`);
  const { initialExpanded } = await import(`${candidate}/bin/doctor-tree.js`);
  const gc = gcOf(aggregateGroups);
  const expanded = new Set([...initialExpanded(buildTree(gc, 10)), "multi-doctor/meh-warn"]);
  const rows = buildListRows(buildTree(gc, 10), false, 0, new Set(), expanded);
  const texts = rows.map(r => r.text);
  // children of the doctor: first check connected with ├─, last with └─
  assert.ok(texts.some(t => t.startsWith("  \u251c\u2500 ")), "non-last child connected with \u251c\u2500");
  assert.ok(texts.some(t => t.startsWith("  \u2514\u2500 ")), "last child connected with \u2514\u2500");
  // instances under a NON-last check hang under the \u2502 guide column
  const underFirst = texts.filter(t => t.startsWith("  \u2502"));
  assert.ok(underFirst.length >= 2, "instances of the first check sit under the guide");
  assert.ok(underFirst.every(t => t.includes("a.ts:")), "guide rows are that check's instances");
});

test("tree: back collapses up — instance to check, check to doctor", async () => {
  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const done = runDashboardOn({ stdin, stdout }, { ...dashInput(aggregateGroups) }, copyAlways);

  // Open the error check (selection starts on the doctor row): down, right.
  stdin.send("j");            // onto check row
  stdin.send("\x1b[C");      // expand it
  stdin.send("j");            // onto its first instance
  let frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.ok(frame.includes("a.ts:1"), "inside the check");

  stdin.send("\x7f");        // backspace: collapse the check, land on it
  frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.ok(!frame.includes("a.ts:1"), "check collapsed");
  assert.ok(/›[▾▸] . Error check/.test(frame), "selection rests on the check row");

  stdin.send("\x1b[D");      // left on the collapsed check: collapse the doctor
  frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.ok(/›▸ . multi-doctor/.test(frame), "doctor collapsed too — back among the doctors");
  assert.ok(frame.includes("3 findings"), "doctor detail pane — back among the doctors");

  stdin.send("q");
  assert.equal(await settle(done), "resolved");
});

test("tree: one multi-check doctor run directly nests like the aggregate", async () => {
  const { buildListRows } = await import(`${candidate}/bin/dashboard.js`);
  const { initialExpanded } = await import(`${candidate}/bin/doctor-tree.js`);
  const gc = gcOf(multiGroups);
  const rows = buildListRows(buildTree(gc, 10), false, 1, new Set(), initialExpanded(buildTree(gc, 10)));
  const texts = rows.map(r => r.text);
  assert.ok(texts.some(t => t.startsWith("  ├─ ")), "non-last check connects with a branch");
  assert.ok(texts.some(t => t.startsWith("  └─ ")), "last check gets the corner");
  assert.ok(texts.some(t => t.startsWith("  │")), "expanded check instances sit under the guide");
});

// ---- copy at every level (the `c` key) ----

test("runDashboard: `c` copies at the level you are on", async () => {
  const copied = [];
  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const deps = { copy: (text) => { copied.push(text); return true; } };
  const done = runDashboardOn({ stdin, stdout }, { ...dashInput(aggregateGroups) }, deps);

  // On a check row: c copies the whole check with all its sites.
  stdin.send("j");              // doctor row -> check row (error check)
  stdin.send("c");
  let frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.match(frame, /copied 2 findings from multi-doctor\/bad-error/);
  assert.match(copied.at(-1), /Fix every finding of one any-doctor check/);
  assert.ok(copied.at(-1).includes("- a.ts:1") && copied.at(-1).includes("- a.ts:2"));

  // On the doctor row: c copies the entire doctor.
  stdin.send("\x7f");          // back: check collapses, selection on it
  stdin.send("\x7f");          // back: doctor collapses, selection on doctor row
  stdin.send("c");
  frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.match(frame, /copied 3 findings from multi-doctor/);
  assert.match(copied.at(-1), /Fix the findings of one any-doctor program/);

  // On an instance row: c copies that finding, same as enter.
  stdin.send("\r");            // expand doctor
  stdin.send("j");              // check row
  stdin.send("\x1b[C");        // expand check
  stdin.send("j");              // instance row
  stdin.send("c");
  frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.match(frame, /copied finding/);
  assert.match(copied.at(-1), /Fix exactly one any-doctor finding/);

  stdin.send("q");
  assert.equal(await settle(done), "resolved");
});

test("rows reference their items directly — no index bookkeeping", async () => {
  const { buildListRows } = await import(`${candidate}/bin/dashboard.js`);
  const { buildTree, initialExpanded } = await import(`${candidate}/bin/doctor-tree.js`);
  const tree = buildTree(gcOf(groups), 10);
  const treeItems = tree.flatMap(d => d.checks.flatMap(g => g.items));
  const rows = buildListRows(tree, false, 0, new Set(), initialExpanded(tree));
  const itemRows = rows.filter(r => r.kind === "item");
  assert.ok(itemRows.every(r => r.item && treeItems.includes(r.item)), "rows carry the tree's own objects, not indices");
});

test("more-row on a flat doctor carries its story — the detail pane never blanks", async () => {
  const { buildListRows } = await import(`${candidate}/bin/dashboard.js`);
  const { buildTree, FINDINGS_PER_CHECK } = await import(`${candidate}/bin/doctor-tree.js`);
  const many = Array.from({ length: FINDINGS_PER_CHECK + 10 }, (_, i) => ({ file: "src/big.ts", line: i + 1 }));
  const groups = [
    { programName: "flat.mjs", meta: { id: "flat-doctor", description: "Flat", severity: "warning" }, findings: many },
    { programName: "solo.mjs", meta: { id: "solo-doctor", description: "Solo", severity: "info" }, findings: [{ file: "c.ts", line: 1 }] },
  ];
  const gc = gcOf(groups);
  const rows = buildListRows(buildTree(gc, 10), false, 0, new Set(), new Set(["flat-doctor"]));
  const more = rows.find(r => r.kind === "more");
  assert.ok(more, "more row present past the cap");
  assert.ok(more.doctor && more.doctor.doctorId === "flat-doctor", "carries the doctor payload");
  assert.equal(more.toggleKey, undefined, "more rows never toggle — inert by kind");
});

// ---- round-2 review gaps: prompt caps and command resolution ----

test("runDashboard: copied prompts resolve the re-run command per doctor", async () => {
  const copied = [];
  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const deps = { copy: (text) => { copied.push(text); return true; } };
  const input = {
    ...dashInput(),
    outcome: {
      ...dashInput().outcome,
      doctorPaths: new Map([["stripe-doctor", "doctors/stripe.mjs"]]),
    },
  };
  const done = runDashboardOn({ stdin, stdout }, input, deps);
  // selection starts on the doctor row; expand and copy the check group
  stdin.send("j");              // onto the check row
  stdin.send("c");
  stdin.send("q");
  assert.equal(await settle(done), "resolved");
  const prompt = copied.at(-1);
  assert.ok(prompt, "check group copied");
  assert.match(prompt, /Verify with `any-doctor run \"doctors\/stripe\.mjs\" \"\.\"`/,
    "the outcome's doctorPaths resolved the doctor that owns the check");
});

test("dashboard and report render the same finding count for one duplicate-laden outcome", async () => {
  const { renderReport } = await import(`${candidate}/bin/report.js`);
  const dupGroups = [
    { programName: "a.mjs", meta: { id: "a", description: "x", severity: "warning" }, findings: [{ file: "src/a.ts", line: 1 }] },
    { programName: "b.mjs", meta: { id: "b", description: "x", severity: "warning" }, findings: [{ file: "src/a.ts", line: 1 }] },
  ];
  const outcome = {
    groups: dupGroups, crashed: [], skippedUnsafe: [], doctorPaths: new Map(),
    fileCount: 4, durationMs: 5, targetDir: ".",
  };
  const report = renderReport({ ...outcome }, false);
  assert.match(report, /1 finding/);
  assert.match(report, /1 duplicate finding hidden/);

  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const done = runDashboardOn({ stdin, stdout }, { outcome, useColor: false }, { copy: () => true });
  await new Promise((r) => setTimeout(r, 10));
  const frame = stdout.frames.find((f) => f.includes("finding")) ?? "";
  assert.match(frame, /1 finding/, "dashboard count matches the report");
  assert.ok(!frame.includes("2 finding"), "the duplicate is hidden on both surfaces");
  stdin.send("q");
  await settle(done);
});

test("dashboard tree keeps a same-doctor second check at one site (both diagnoses visible)", async () => {
  const twoChecks = [{
    programName: "convex.mjs",
    meta: {
      id: "convex", description: "x", severity: "warning",
      checks: [
        { id: "filter-table-scan", description: "Filter scans the table", severity: "warning" },
        { id: "unbounded-collect", description: "Collect is unbounded", severity: "warning" },
      ],
    },
    findings: [
      { rule: "filter-table-scan", file: "src/list.ts", line: 5 },
      { rule: "unbounded-collect", file: "src/list.ts", line: 5 },
    ],
  }];
  const outcome = {
    groups: twoChecks, crashed: [], skippedUnsafe: [], doctorPaths: new Map(),
    fileCount: 4, durationMs: 5, targetDir: ".",
  };
  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const done = runDashboardOn({ stdin, stdout }, { outcome, useColor: false }, { copy: () => true });
  await new Promise((r) => setTimeout(r, 10));
  const frame = stdout.frames.find((f) => f.includes("finding")) ?? "";
  assert.match(frame, /2 findings/, "both checks count on the dashboard as in the report");
  assert.ok(frame.includes("Filter scans the table"), "the first check row is in the tree");
  assert.ok(frame.includes("Collect is unbounded"), "the second check survives dedupe in the tree");
  stdin.send("q");
  await settle(done);
});

test("tree: the doctor row shows its own score against the same denominator", async () => {
  const { buildTree } = await import(`${candidate}/bin/doctor-tree.js`);
  const { buildListRows } = await import(`${candidate}/bin/dashboard.js`);
  const twoDoctors = [
    { programName: "a.mjs", meta: { id: "a", description: "x", severity: "warning" }, findings: [{ file: "f1.ts", line: 1 }, { file: "f2.ts", line: 1 }] },
    { programName: "b.mjs", meta: { id: "b", description: "x", severity: "warning" }, findings: [{ file: "f1.ts", line: 9 }] },
  ];
  const tree = buildTree(gcOf(twoDoctors), 10);
  const rows = buildListRows(tree, false, 0, new Set(), new Set(["a", "b"]));
  const aRow = rows.find(r => r.doctor?.doctorId === "a");
  assert.match(aRow.text, /×2 · 90/, "the doctor row shows its own score");
  const bRow = rows.find(r => r.doctor?.doctorId === "b");
  assert.match(bRow.text, /×1 · 95/);
});

test("dashboard header: the selected doctor's score, never a cohort total", async () => {
  const { dashboardFrame } = await import(`${candidate}/bin/dashboard.js`);
  const { buildTree } = await import(`${candidate}/bin/doctor-tree.js`);
  const twoDoctors = [
    { programName: "a.mjs", meta: { id: "a", description: "x", severity: "warning" }, findings: [{ file: "f1.ts", line: 1 }, { file: "f2.ts", line: 1 }] },
    { programName: "b.mjs", meta: { id: "b", description: "x", severity: "warning" }, findings: [{ file: "f1.ts", line: 9 }] },
  ];
  const gc = gcOf(twoDoctors);
  const tree = buildTree(gc, 10);
  const state = (selectedRow) => ({ tree, selectedRow, readKeys: new Set(), readSource: () => null, expanded: new Set(["a", "b"]), filesTotal: 10, durationMs: 5, useColor: false, cols: 120, rows: 34 });

  // Selection on doctor a's row: the header is a's report.
  const rowsA = (await import(`${candidate}/bin/dashboard.js`)).buildListRows(tree, false, 0, new Set(), new Set(["a", "b"]));
  const aRow = rowsA.findIndex(r => r.doctor?.doctorId === "a");
  const frameA = dashboardFrame(state(aRow));
  assert.match(frameA, /a  Score: 90 \/ 100/);
  assert.match(frameA, /2 findings · 8\/10 files clean/);

  // Move selection to doctor b: the header follows.
  const bRow = rowsA.findIndex(r => r.doctor?.doctorId === "b");
  const frameB = dashboardFrame(state(bRow));
  assert.match(frameB, /b  Score: 95 \/ 100/);
  assert.match(frameB, /1 finding · 9\/10 files clean/);

  // No cohort number anywhere: the union score (92) never appears.
  assert.ok(!frameA.includes("92"), "no cohort total in the dashboard header");
});

test("dashboard header: a clean scan has no score to scope — No findings", async () => {
  const { dashboardFrame } = await import(`${candidate}/bin/dashboard.js`);
  const frame = dashboardFrame({ tree: [], selectedRow: 0, readKeys: new Set(), readSource: () => null, filesTotal: 6, durationMs: 5, useColor: false, cols: 120, rows: 34 });
  assert.match(frame, /No findings/);
  assert.match(frame, /0 findings · 6 files/);
});

test("dashboard header: zero groups over zero files is n/a in yellow, never a green 100", async () => {
  const { dashboardFrame } = await import(`${candidate}/bin/dashboard.js`);
  const plain = dashboardFrame({ tree: [], selectedRow: 0, readKeys: new Set(), readSource: () => null, filesTotal: 0, durationMs: 114, useColor: false, cols: 120, rows: 34 });
  assert.match(plain, /Score: n\/a — no files scanned/);
  assert.match(plain, /0 findings · 0 files · 114ms/);
  assert.ok(!plain.includes("Excellent"), "an empty scan claims no grade");
  assert.ok(!plain.includes("No findings"), "no findings headline over nothing checked");
  const colored = dashboardFrame({ tree: [], selectedRow: 0, readKeys: new Set(), readSource: () => null, filesTotal: 0, durationMs: 114, useColor: true, cols: 120, rows: 34 });
  assert.match(colored, /\u001b\[1m\u001b\[33mScore: n\/a/, "the n/a line is toned yellow, not green");
  assert.match(colored, /\u001b\[33m░/, "the bar stays empty and yellow — nothing was measured");
});

test("dashboard header: a doctor over zero scanned files reports n/a, not Excellent", async () => {
  const { buildListRows, dashboardFrame } = await import(`${candidate}/bin/dashboard.js`);
  const { buildTree } = await import(`${candidate}/bin/doctor-tree.js`);
  // Two doctors whose findings name files outside the default-extension
  // walk: tree rows exist, but the scan's denominator is zero.
  const mk = (id, file) => ({ programName: id + ".mjs", meta: { id, description: "x", severity: "warning" }, findings: [{ file, line: 1 }] });
  const groups = [mk("a", "src/spec-a.xs"), mk("b", "src/spec-b.xs")];
  const tree = buildTree(gcOf(groups), 0);
  const rows = buildListRows(tree, false, 0, new Set(), new Set(["a", "b"]));
  const aRow = rows.findIndex(r => r.doctor?.doctorId === "a");
  assert.ok(aRow >= 0, "doctor a has a row");
  assert.match(rows[aRow].text, /· n\/a/, "the doctor row refuses the vacuous 100 too");
  const frame = dashboardFrame({ tree, selectedRow: aRow, readKeys: new Set(), readSource: () => null, expanded: new Set(["a", "b"]), filesTotal: 0, durationMs: 114, useColor: false, cols: 120, rows: 34 });
  assert.match(frame, /a  Score: n\/a — no files scanned/);
  assert.match(frame, /1 finding · 0 files · 114ms/);
  assert.ok(!frame.includes("Excellent"), "an empty scan claims no grade");
});

test("tree: a doctor with zero findings contributes no node — clean cohorts render, never crash", async () => {
  const { buildTree } = await import(`${candidate}/bin/doctor-tree.js`);
  const clean = { programName: "clean.mjs", meta: { id: "clean-doctor", description: "x", severity: "warning" }, findings: [] };
  assert.deepEqual(buildTree(gcOf([clean]), 10), [], "the empty-bucket group is filtered before any checks[0] deref");
  const mixed = buildTree(gcOf([groups[0], clean]), 10);
  assert.deepEqual(mixed.map(d => d.doctorId), ["stripe-doctor"], "the clean doctor is simply absent");
});

// ---- remembered decisions in the dashboard (M2) ---------------------------

test("dashboard: a records an accepted decision through the reason prompt and hides the finding", async () => {
  const decided = [];
  const reversedKeys = [];
  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const deps = {
    copy: () => true,
    decide: (d) => { decided.push(d); return { ok: true }; },
    reverse: (key) => { reversedKeys.push(key); return { ok: true }; },
  };
  // (provenance parity is asserted after submit: the write input must
  // carry what the disk record needs — the restart-survival probe)
  // Readable evidence (stale findings carry no decidable key — F5).
  const target = fs.mkdtempSync(path.join(os.tmpdir(), "any-doctor-m2view-"));
  fs.mkdirSync(path.join(target, "src"), { recursive: true });
  fs.writeFileSync(path.join(target, "src", "a.ts"), "const pad = 0;\nconst charges = chargesCreate(1);\nconst pad2 = 2;\nconst pad3 = 3;\nconst pad4 = 4;\nconst pad5 = 5;\nconst pad6 = 6;\nconst pad7 = 7;\nconst pad8 = 8;\nconst charges2 = chargesCreate(9);\n");
  fs.writeFileSync(path.join(target, "src", "b.ts"), "const other = 7;\n");
  try {
  const baseOutcome = dashInput().outcome;
  const realOutcome = { ...baseOutcome, targetDir: target };
  const capture = captureScan(target, deriveSummaryOf(realOutcome).groups, false, []);
  const view = reviewOf(capture, [], encodeDecisionKey, provOf("stripe-doctor", "export const meta = { id: 'stripe-doctor' }"));
  const rawKey = view.rawKeyByReadKey.get("stripe-doctor/charges-create@src/a.ts:2");
  assert.ok(rawKey !== undefined, "the fixture finding has an identity key");
  const done = runDashboardOn(
    { stdin, stdout },
    { outcome: realOutcome, useColor: false, view },
    deps,
  );
  // selection starts on the doctor row; walk onto the first finding
  stdin.send("j");            // doctor row -> first finding (flat, single-check)
  stdin.send("a");            // open the reason prompt
  let frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.ok(frame.includes("Reason for accepting"), "the prompt opens with its disposition");
  stdin.send("intentional legacy charge");
  stdin.send("\r");
  frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.match(frame, /accepted — hidden from the active list/, "the notice confirms the decision");
  assert.ok(!frame.includes("src/a.ts:2"), "the decided finding left the active tree");
  assert.equal(decided.length, 1);
  assert.equal(decided[0].key, rawKey);
  assert.equal(decided[0].disposition, "accepted");
  assert.equal(decided[0].reason, "intentional legacy charge");
  assert.equal(decided[0].actor, "dashboard");
  assert.ok(decided[0].provenance !== undefined
    && decided[0].provenance.programDigest === provOf("stripe-doctor", "export const meta = { id: 'stripe-doctor' }").programDigests.get("stripe-doctor"),
    "the WRITE carries the run's provenance — the disk record survives restart without a false 'doctor changed'");

  // v reveals the review view: dim row with its disposition
  stdin.send("v");
  frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.ok(frame.includes("src/a.ts:2"), "review view shows the decided finding");
  assert.match(frame, /✓ accepted/, "with its disposition");

  // u on it reverses
  stdin.send("u");
  frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.match(frame, /decision reversed/, "u reverses through the injected dep");
  assert.equal(reversedKeys.length, 1);
  assert.deepEqual(reversedKeys, [rawKey]);
  stdin.send("q");
  await settle(done);
  } finally {
    fs.rmSync(target, { recursive: true, force: true });
  }
});

test("dashboard: x records not-applicable; an empty reason is refused; esc cancels", async () => {
  const decided = [];
  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const deps = { copy: () => true, decide: (d) => { decided.push(d); return { ok: true }; } };
  const target2 = fs.mkdtempSync(path.join(os.tmpdir(), "any-doctor-m2view2-"));
  fs.mkdirSync(path.join(target2, "src"), { recursive: true });
  fs.writeFileSync(path.join(target2, "src", "a.ts"), "const pad = 0;\nconst charges = chargesCreate(1);\nconst pad2 = 2;\nconst pad3 = 3;\nconst pad4 = 4;\nconst pad5 = 5;\nconst pad6 = 6;\nconst pad7 = 7;\nconst pad8 = 8;\nconst charges2 = chargesCreate(9);\n");
  fs.writeFileSync(path.join(target2, "src", "b.ts"), "const other = 7;\n");
  try {
  const outcome2 = { ...dashInput().outcome, targetDir: target2 };
  const capture2 = captureScan(target2, deriveSummaryOf(outcome2).groups, false, []);
  const done = runDashboardOn({ stdin, stdout }, { outcome: outcome2, useColor: false, view: reviewOf(capture2, [], encodeDecisionKey, provOf("stripe-doctor", "x")) }, deps);
  stdin.send("j");   // onto first finding (flat, single-check)
  stdin.send("x");
  stdin.send("\r");                                          // empty reason
  let frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.match(frame, /a reason is required/, "empty reason refused");
  stdin.send("\x1b");                                        // esc cancels
  frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.ok(!frame.includes("Reason for"), "prompt closed");
  assert.equal(decided.length, 0, "nothing recorded");
  stdin.send("q");
  await settle(done);
  } finally {
    fs.rmSync(target2, { recursive: true, force: true });
  }
});

test("dashboard: a resurfaced decision renders the reassessment mark", async () => {
  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const target3 = fs.mkdtempSync(path.join(os.tmpdir(), "any-doctor-m2view3-"));
  fs.mkdirSync(path.join(target3, "src"), { recursive: true });
  fs.writeFileSync(path.join(target3, "src", "a.ts"), "const pad = 0;\nconst charges = chargesCreate(1);\nconst pad2 = 2;\nconst pad3 = 3;\nconst pad4 = 4;\nconst pad5 = 5;\nconst pad6 = 6;\nconst pad7 = 7;\nconst pad8 = 8;\nconst charges2 = chargesCreate(9);\n");
  fs.writeFileSync(path.join(target3, "src", "b.ts"), "const other = 7;\n");
  try {
  const outcome3 = { ...dashInput().outcome, targetDir: target3 };
  const capture3 = captureScan(target3, deriveSummaryOf(outcome3).groups, false, []);
  const view3 = reviewOf(capture3, [], encodeDecisionKey);
  view3.reassessing.push({ checkKey: "stripe-doctor/charges-create", file: "src/a.ts", reason: "old reason" });
  const done = runDashboardOn({ stdin, stdout }, { outcome: outcome3, useColor: false, view: view3 }, { copy: () => true });
  stdin.send("j");
  const frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.match(frame, /⚠ decision needs reassessment/, "the resurfaced finding warns");
  stdin.send("q");
  await settle(done);
  } finally {
    fs.rmSync(target3, { recursive: true, force: true });
  }
});

test("dashboard: recording on a shared identity refuses — matching what a rescan holds back", async () => {
  const decided = [];
  const stdin = new FakeStdin();
  const stdout = new FakeStdout();
  const deps = { copy: () => true, decide: (x) => { decided.push(x); return { ok: true }; } };
  // Real files with IDENTICAL lines: the identity key is shared (same
  // digest/context/scope), which only readable evidence can prove.
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "any-doctor-shared-"));
  try {
  fs.writeFileSync(path.join(tmp, "f.ts"), "const twin = 1;\nconst pad = 2;\nconst pad2 = 3;\nconst pad3 = 4;\nconst twin = 1;\n");
  const groups = [{
    programName: "doc.mjs",
    meta: { id: "doc", description: "d", severity: "warning" },
    findings: [{ rule: "rule", file: "f.ts", line: 1 }, { rule: "rule", file: "f.ts", line: 5 }],
  }];
  const outcome = { groups, crashed: [], skippedUnsafe: [], doctorPaths: new Map(), fileCount: 1, durationMs: 1, targetDir: tmp };
  // The view derives ambiguity itself from the shared identity.
  const capture4 = captureScan(tmp, deriveSummaryOf(outcome).groups, false, []);
  const view4 = reviewOf(capture4, [], encodeDecisionKey);
  const sharedCount = [...view4.rows.values()].filter((r) => r.ambiguous === 2).length;
  assert.equal(sharedCount, 2, "the view itself marks both copies as sharing an identity");
  const done = runDashboardOn({ stdin, stdout }, { outcome, useColor: false, view: view4 }, deps);
  stdin.send("j");          // onto the first finding
  stdin.send("a");          // open the prompt
  stdin.send("twin copies");
  stdin.send("\r");        // submit — must REFUSE (identity shared)
  const frame = stdout.frames.filter(f => f.includes("\x1b[H")).at(-1);
  assert.match(frame, /held back: 2 identical occurrences share this identity/, "the refusal explains the rescan's law");
  assert.equal(decided.length, 0, "nothing recorded");
  assert.match(frame, /identical copies share this iden/, "the rows carry the ambiguity mark (list column truncates)");
  stdin.send("\x1b");      // cancel the prompt
  stdin.send("q");
  await settle(done);
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
});

for(const narrowed of [false,true])test(`runDashboard: mixed run discloses ${narrowed?'narrowed':'clean'} zero-finding doctor through navigation`,async()=>{
  const quiet={programName:'quiet.mjs',meta:{id:'quiet-doctor',description:'Quiet',severity:'warning',checks:[{id:'quiet',description:'Quiet',needs:['calls']}]},findings:[]};
  const input=dashInput([groups[0],quiet]);input.outcome.analysisAvailable=!narrowed;
  const stdin=new FakeStdin(),stdout=new FakeStdout();
  const done=runDashboardOn({stdin,stdout},input,copyAlways);
  const expected=new RegExp(`${narrowed?'△':'✔'} quiet-doctor — ${narrowed?'narrowed':'clean'}`);
  assert.match(stdout.frames.at(-1),expected);
  stdin.send('\x1b[B');
  assert.match(stdout.frames.at(-1),expected);assert.match(stdout.frames.at(-1),/stripe-doctor/);
  stdin.send('q');assert.equal(await settle(done),'resolved');
});


for(const [count,narrowed,rows] of [[0,false,34],[1,false,34],[1,true,34],[5,true,34],[40,true,14],[40,true,10],[40,true,8]])
 for(const cols of [80,140])test(`quiet status budget: ${count} quiet doctors, narrowed=${narrowed}, ${cols}x${rows}`,async()=>{
  const quiet=Array.from({length:count},(_,i)=>({programName:`quiet-${i}.mjs`,meta:{id:`quiet-${i}`,description:'Quiet',severity:'warning',checks:[{id:'q',description:'Quiet',needs:['calls']}]},findings:[]}));
  const input=dashInput([...groups,...quiet]);input.outcome.analysisAvailable=!narrowed;
  const stdin=new FakeStdin(),stdout=new FakeStdout();stdout.rows=rows;stdout.columns=cols;
  const done=runDashboardOn({stdin,stdout},input,copyAlways);
  try {
   stdin.send('j');stdin.send('j');stdin.send('c');
   const frames=stdout.frames.filter(f=>f.includes('\x1b[H'));
   assert.ok(frames.length>=3,'navigation and notice repaint');
   for(const frame of frames){
    assertFrameFits(frame,{cols,rows,useColor:false,label:`painted quiet=${count}`});
    assert.equal((frame.match(/\x1b\[K/g)||[]).length,rows-1,'each repainted row clears stale text');
    assert.match(frame,/\x1b\[J/,'clear below the frame');
    assert.match(frame,/stripe-doctor/);
    if(count&&count<40)for(let i=0;i<count;i++)assert.match(frame,new RegExp(`${narrowed?'△':'✔'} quiet-${i} — ${narrowed?'narrowed':'clean'}`));
    if(count===40)assert.match(frame,/\d+ (?:more|omitted) quiet doctors/,'excess statuses have a bounded omitted-count row');
   }
   assert.notEqual(frames[0],frames[1],'selected tree still changes through navigation');
  } finally {stdin.send('q');await done;}
 });


test('small dashboard budgets coverage notices and a mixed quiet cohort',()=>{
 const tree=buildTree(gcOf(groups),2);
 for(const rows of [3,4,5,8,10,14,34]){
  const frame=dashboardFrame({tree,selectedRow:0,readKeys:new Set(),readSource:()=>null,filesTotal:2,durationMs:2,useColor:false,cols:140,rows,
   zeroFindingDoctors:Array.from({length:40},(_,i)=>({id:`quiet-${i}`,narrowed:i%2===0})),
   coverageNotice:'semantic coverage narrowed',skippedUnsafe:['unsafe.mjs']});
  assertFrameFits(frame,{cols:140,rows,useColor:false,label:'small mixed notices'});
  assert.match(frame,/\d+ more quiet doctors/);
  assert.match(frame,/\d+ narrowed, \d+ clean/);
  assert.match(frame,/semantic coverage narrowed/);
 }
});


const widthCases = [
  ...[[0,false],[1,false],[1,true],[5,true]].map(([count,narrowed])=>({count,narrowed,rows:34})),
  ...[3,4,5,8,10,14,34].map(rows=>({count:40,narrowed:true,rows})),
];
for (const useColor of [false,true]) for (const cols of [80,140]) for (const {count,narrowed,rows} of widthCases) {
  const label=`width boundary: ${cols}x${rows}, quiet=${count}, narrowed=${narrowed}, color=${useColor}`;
  test(label,()=>{
    const quiet=Array.from({length:count},(_,i)=>({id:`quiet-${i}`,narrowed:count===40?i%2===0:narrowed}));
    const frame=dashboardFrame({tree:buildTree(gcOf(groups),2),selectedRow:0,readKeys:new Set(),readSource:()=>null,filesTotal:2,durationMs:2,useColor,cols,rows,
      zeroFindingDoctors:quiet,coverageNotice:'semantic coverage narrowed',skippedUnsafe:['unsafe.mjs']});
    assertFrameFits(frame,{cols,rows,useColor,label});
    const plain=frame.replace(/\x1b\[[0-9;]*m/g,'');
    if(count===40){
      assert.match(plain,/\d+ more quiet doctors — \d+ narrowed, \d+ clean/,'omitted and coverage counts fit at these widths');
      const shown=[...plain.matchAll(/[△✔] quiet-\d+ — (?:narrowed|clean)/g)].length;
      const omitted=Number(plain.match(/(\d+) more quiet doctors/)[1]);
      assert.equal(shown+omitted,count,'every quiet doctor is visible or counted');
    } else for(const doctor of quiet) assert.ok(plain.includes(`${doctor.narrowed?'△':'✔'} ${doctor.id} — ${doctor.narrowed?'narrowed':'clean'}`));
    if(rows>=8)assert.match(plain,/↑↓ move/,'footer retains the leading navigation hint');
  });
}

for(const useColor of [false,true])for(const cols of [20,40,80,140])for(const rows of [5,34])test(`long text cannot escape ${cols}x${rows}, color=${useColor}`,()=>{
 const long='very-long-name-'.repeat(30);
 const custom=[{...groups[0],meta:{...groups[0].meta,id:`doctor-${long}`},findings:[{rule:'charges-create',file:`src/${long}.ts`,line:1}]}];
 const frame=dashboardFrame({tree:buildTree(gcOf(custom),2),selectedRow:1,readKeys:new Set(),readSource:()=>[long],filesTotal:2,durationMs:2,useColor,cols,rows,
   zeroFindingDoctors:Array.from({length:40},(_,i)=>({id:`quiet-${long}-${i}`,narrowed:i%2===0})),
   coverageNotice:`semantic coverage narrowed ${long}`,skippedUnsafe:[`unsafe-${long}`],notice:`copied ${long}`});
 assertFrameFits(frame,{cols,rows,useColor,label:'long controlled text'});
 const plain=frame.replace(/\x1b\[[0-9;]*m/g,'');
 assert.match(plain,/doctor-/);
 assert.match(plain,/\d+ more quiet/,'bounded cohort disclosure survives long IDs');
 assert.match(plain,/△/,'the narrowed status mark leads the long ID');
 if(cols>=80)assert.match(plain,/\d+ narrowed, \d+ clean/);
});

for(const useColor of [false,true])test(`compact color=${useColor} repaints physical rows and keeps navigation`,async()=>{
 const quiet=Array.from({length:40},(_,i)=>({programName:`q-${i}`,meta:{id:`quiet-${i}`,description:'Quiet',severity:'warning'},findings:[],
   ...(i%2===0?{semantic:{protocolVersion:1,provider:{id:'syntax',version:'1',available:true},incomplete:true,narrowed:[{check:'q',reason:'unsupported-expression',occurrences:1,files:[]}]} }: {})}));
 const input=dashInput([...groups,...quiet]);input.useColor=useColor;
 const stdin=new FakeStdin(),stdout=new FakeStdout();stdout.columns=80;stdout.rows=8;
 const done=runDashboardOn({stdin,stdout},input,copyAlways);
 try{
   stdin.send('j');stdin.send('j');stdin.send('c');stdin.send('k');
   const frames=stdout.frames.filter(f=>f.includes('\x1b[H'));
   assert.ok(frames.length>=4);
   for(const frame of frames){
     assertFrameFits(frame,{cols:80,rows:8,useColor,label:'compact painted navigation'});
     assert.equal((frame.match(/\x1b\[K/g)||[]).length,7);
     assert.match(frame,/\x1b\[J/);
     assert.match(unpaint(frame),/more quiet doctors/);
   }
   assert.notEqual(frames[0],frames[1]);
 }finally{stdin.send('q');await done;}
});

for(const useColor of [false,true])test(`non-BMP notice text obeys the same visible-width boundary, color=${useColor}`,()=>{
 for(const cols of [20,80]){
  const frame=dashboardFrame({tree:buildTree(gcOf(groups),2),selectedRow:0,readKeys:new Set(),readSource:()=>null,filesTotal:2,durationMs:2,useColor,cols,rows:8,
    notice:`copied ${'🧪'.repeat(100)}`,zeroFindingDoctors:[{id:'quiet',narrowed:true}]});
  assertFrameFits(frame,{cols,rows:8,useColor,label:'non-BMP notice'});
  assert.match(frame,/△/);
 }
});


const unicodeSizes = [[20,8],[40,8],[80,3],[80,8],[80,34],[140,34]];
for (const [cols, rows] of unicodeSizes) test(`Unicode dashboard independent cells ${cols}x${rows}`, () => {
  const long = '界界界e\u0301🧪👩‍💻❤️'.repeat(12);
  const custom = [{...groups[0], meta:{...groups[0].meta,id:`医師-${long}`}, findings:[{rule:'charges-create',file:`src/文件-${long}.ts`,line:1}]}];
  const widths = [];
  for (const useColor of [false,true]) {
    const frame = dashboardFrame({tree:buildTree(gcOf(custom),2),selectedRow:1,readKeys:new Set(),readSource:()=>[long],filesTotal:2,durationMs:2,useColor,cols,rows,
      zeroFindingDoctors:Array.from({length:40},(_,i)=>({id:`界-${long}-${i}`,narrowed:i%2===0})),
      coverageNotice:`semantic coverage narrowed ${long}`,skippedUnsafe:[`unsafe-${long}`],notice:`copied ${long}`});
    assertFrameFits(frame,{cols,rows,useColor,label:'Unicode matrix'});
    const plain=plainSgr(frame);
    assert.match(plain,/△/, 'narrowed coverage is disclosed');
    assert.match(plain,/\d+ more quiet/, 'omitted quiet doctors stay represented');
    if(cols>=80) assert.match(plain,/\d+ narrowed, \d+ clean/);
    widths.push(frame.split('\n').map(terminalCells));
  }
  assert.deepEqual(widths[0], widths[1], 'color does not change terminal-cell widths');
});

for(const useColor of [false,true])test(`CJK physical-row reproduction 20x8 color=${useColor}`,()=>{
 const custom=[{...groups[0],meta:{...groups[0].meta,id:'doctor-'+'界'.repeat(30)},findings:[{rule:'charges-create',file:`src/${'界'.repeat(30)}.ts`,line:1}]}];
 const frame=dashboardFrame({tree:buildTree(gcOf(custom),2),selectedRow:1,readKeys:new Set(),readSource:()=>null,filesTotal:2,durationMs:2,useColor,cols:20,rows:8,
  zeroFindingDoctors:[{id:'quiet-'+'界'.repeat(20),narrowed:true}]});
 assertFrameFits(frame,{cols:20,rows:8,useColor,label:'CJK reproduction'});
 assert.match(plainSgr(frame),/△/);
});

for(const useColor of [false,true])test(`Unicode compact repaint color=${useColor}`,async()=>{
 const custom=[{...groups[0],meta:{...groups[0].meta,id:'医師-界👩‍💻'},findings:[{rule:'charges-create',file:'src/文件-e\u0301🧪.ts',line:1}]}];
 const input=dashInput([...custom,groups[1]]);input.useColor=useColor;
 const stdin=new FakeStdin(),stdout=new FakeStdout();stdout.columns=20;stdout.rows=8;
 const done=runDashboardOn({stdin,stdout},input,copyAlways);
 try{
  stdin.send('j');stdin.send('c');stdin.send('k');
  const frames=stdout.frames.filter(f=>f.includes('\x1b[H'));
  assert.ok(frames.length>=4);assert.notEqual(frames[0],frames[1]);
  for(const frame of frames){
   assertFrameFits(frame,{cols:20,rows:8,useColor,label:'Unicode painted navigation'});
   assert.equal((frame.match(/\x1b\[K/g)||[]).length,7);assert.match(frame,/\x1b\[J/);
  }
 }finally{stdin.send('q');await done;}
});
