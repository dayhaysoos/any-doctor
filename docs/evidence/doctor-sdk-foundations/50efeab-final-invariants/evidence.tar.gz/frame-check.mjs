import assert from 'node:assert/strict';
import path from 'node:path';
const root=path.resolve(process.argv[2]);
const {dashboardFrame}=await import(path.join(root,'bin/dashboard.js'));
const {deriveSummary}=await import(path.join(root,'bin/summary.js'));
const {buildTree}=await import(path.join(root,'bin/doctor-tree.js'));
const findings=[{programName:'positive.mjs',meta:{id:'positive',description:'Positive control',severity:'warning'},findings:[{file:'example.ts',line:1},{file:'example.ts',line:2}]}];
const summary=deriveSummary({groups:findings,crashed:[],fileCount:2,durationMs:1});
const tree=buildTree(summary.groupChecks,2),results=[];
for(const [count,rows] of [[0,34],[1,34],[5,34],[40,14],[40,10],[40,8]]){
 const quiet=Array.from({length:count},(_,i)=>({id:`quiet-${i}`,narrowed:i%2===0}));
 for(const cols of [80,140]){
  const frame=dashboardFrame({tree,selectedRow:0,readKeys:new Set(),readSource:()=>null,filesTotal:2,durationMs:1,useColor:false,rows,cols,zeroFindingDoctors:quiet});
  const lines=frame.split('\n');assert.equal(lines.length,rows-1);if(count===40)assert.match(frame,/more quiet doctors/);
  results.push({quietDoctors:count,terminal:{rows,cols},frameHeight:lines.length,statusRows:lines.filter(l=>/quiet-\d|more quiet doctors/.test(l))});
 }
}
console.log(JSON.stringify({passed:results.length,failed:0,skipped:0,results},null,2));
