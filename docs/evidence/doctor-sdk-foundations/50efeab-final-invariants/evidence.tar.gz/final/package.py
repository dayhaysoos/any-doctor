import pathlib,subprocess,json,hashlib,tarfile
R=pathlib.Path('<repo>');O=pathlib.Path(__file__).parent

def run(n,args,cwd=R):
 p=subprocess.run(list(map(str,args)),cwd=cwd,capture_output=True,text=True);(O/(n+'.stdout')).write_text(p.stdout);(O/(n+'.stderr')).write_text(p.stderr);(O/(n+'.command.json')).write_text(json.dumps(dict(command=list(map(str,args)),cwd=str(cwd),exit=p.returncode),indent=2));assert p.returncode==0,(n,p.stderr[-500:]);return p
P=O/'package';P.mkdir();q=run('pack',['npm','pack','--ignore-scripts','--pack-destination',P,'--json']);pack=json.loads(q.stdout)[0];a=P/pack['filename'];
with tarfile.open(a) as t:
 for m in t.getmembers():
  if m.isfile():assert t.extractfile(m).read()==(R/pathlib.PurePosixPath(m.name).relative_to('package')).read_bytes(),m.name
(O/'artifact.json').write_text(json.dumps(dict(path=str(a),sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size,files=len(pack['files'])),indent=2))
run('optional',['node',R/'dev/doctor-sdk/check-optional-provider.mjs',a,O/'optional-consumer'])
C=O/'consumer';C.mkdir();(C/'package.json').write_text('{"private":true}')
run('install',['npm','install','--ignore-scripts','--no-audit','--no-fund',a],C)
run('packed-gates',['python3',O/'gates.py','packed',C/'node_modules/any-doctor'])
