import pathlib,subprocess,json,hashlib,tarfile,time
R=pathlib.Path('/Users/nickdejesus/Code/any-doctor');O=pathlib.Path(__file__).parent;T=pathlib.Path('/tmp/any-doctor-frozen-sift');M=json.loads((R/'docs/evidence/consumer-analysis/sift-manifest.json').read_text())
def manifest(name):
 bad=[f['file'] for f in M['files'] if not (T/f['file']).is_file() or hashlib.sha256((T/f['file']).read_bytes()).hexdigest()!=f['sha256']];j={'files':len(M['files']),'matched':len(M['files'])-len(bad),'mismatches':bad};(O/(name+'.json')).write_text(json.dumps(j,indent=2));assert not bad

def run(name,args,cwd=R):
 t=time.monotonic();p=subprocess.run(list(map(str,args)),cwd=cwd,capture_output=True,text=True);(O/(name+'.stdout')).write_text(p.stdout);(O/(name+'.stderr')).write_text(p.stderr);(O/(name+'.command.json')).write_text(json.dumps({'command':list(map(str,args)),'cwd':str(cwd),'exit':p.returncode,'wallMs':round(1000*(time.monotonic()-t))},indent=2));assert p.returncode==0,(name,p.stderr[-500:],p.stdout[-500:]);return p
for label,format in [('local-convex','json'),('local-convex-human','human')]:run(label,['node','bin/cli.js','verify','doctors/convex.mjs',*(['--format','json'] if format=='json' else [])])
run('verify-all',['node','bin/cli.js','verify','--all'])
P=O/'package';P.mkdir();p=run('pack',['npm','pack','--ignore-scripts','--pack-destination',P,'--json']);m=json.loads(p.stdout)[0];a=P/m['filename']
with tarfile.open(a) as t:
 for f in t:
  if f.isfile():assert t.extractfile(f).read()==(R/pathlib.PurePosixPath(f.name).relative_to('package')).read_bytes()
(O/'artifact.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'path':str(a),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'bytes':a.stat().st_size,'files':len(m['files'])},indent=2))
C=O/'consumer';C.mkdir();(C/'package.json').write_text('{"private":true}');run('install',['npm','install','--ignore-scripts','--no-audit','--no-fund',a],cwd=C);B=C/'node_modules/any-doctor';run('packed-convex',['node',B/'bin/cli.js','verify',B/'doctors/convex.mjs','--format','json'],cwd=C)
manifest('manifest-before-local');run('local-sift',['node','bin/cli.js','run','doctors/convex.mjs',T,'--format','json']);manifest('manifest-after-local')
manifest('manifest-before-packed');run('packed-sift',['node',B/'bin/cli.js','run',B/'doctors/convex.mjs',T,'--format','json'],cwd=C);manifest('manifest-after-packed')
run('existing-adversarial',['node','dev/convex-analysis/run-cases.mjs',R,O/'existing-cases'])
print('Baseline complete',flush=True)
